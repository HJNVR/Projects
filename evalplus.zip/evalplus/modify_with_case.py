from geterror import execute_code
import sys
from draft import parse_code_block,debug_in_rounds
sys.path.append('/data0/panguchain/liyusu/uniaigc/')
from uniaigc import generate
debugprompt = '''
you are doing homework , which is a complete code task , really easy for you .
there is the original file to complete:
```python
{prompt}
```
here is your draft file:
```python
{exctuable}
```
based on the task , it should be able to pass the cases:
```python
{cases}
```
you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
please analysis the infor mation carefully , then modify your draft , add some necessary print for debug .you should organized your reply in such format:

#reply
## the analysis based on the info mation 
```analysis
{{your analisis here}}
```
## the modified code draft
```python
{{your_code_here}}
```
##summary
your summary

sure,here is my reply

#reply

'''

def modify_code_using_testcases(prompt,exectuable,testcases,loops = 10):
    cases = ''
    for t in testcases['assert lines']:
        cases += t+'\n'
    for _ in range(loops):
        error,out = execute_code(exectuable+'\n'+cases)
        quary = debugprompt.format(
            prompt = prompt,
            exctuable = exectuable,
            cases = cases,
            error = error,
            out=out
        )
        answer = generate(quary)
        exectuable = parse_code_block(answer)['code']
        #exectuable = debug_in_rounds(exectuable,loops=1)
    return 'failed to solve the issue'
        


from onlyfordebug import get_prompt
from gettestcase import get_test_case
def new_query_from_code(code,p):
    prompt = get_prompt(p)
    testcases = get_test_case(prompt)
    cases = ''
    for t in testcases['assert lines']:
        cases += t+'\n'
    e,o = execute_code(code)
    quary = debugprompt.format(
        prompt = prompt,
        exctuable = code,
        cases = cases,
        error = e,
        out=o
    )
    return quary
