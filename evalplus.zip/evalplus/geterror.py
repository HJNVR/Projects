import contextlib
import io
import traceback
from typing import Optional
class ReadWriteStringIO(io.StringIO):
    """StringIO that can be read from and written to"""

    def readable(self, *args, **kwargs):
        """Returns True if the IO object can be read."""
        return True    
class redirect_stdin(contextlib._RedirectStream):  # type: ignore
    _stream = "stdin"
def execute_code(code: str):
    stream = ReadWriteStringIO()
    error_and_traceback = ""
    standard_out = ""
    try:
        with contextlib.redirect_stdout(stream):
            with contextlib.redirect_stderr(stream):
                with redirect_stdin(stream):
                    exec(code,{})
    except Exception as e:
        error_and_traceback = "".join(traceback.format_exception(None, e, e.__traceback__))
    standard_out = stream.getvalue()
    return error_and_traceback, standard_out
# Usage:
code = ''' 
import numpy as np
def f():
    print(np.pi)
    return np.pi
print(f())
'''
if __name__=='__main__':
    error_and_traceback, standard_out = execute_code(code)
    print("Error and traceback:\n", error_and_traceback)
    print("Standard out:\n", standard_out)