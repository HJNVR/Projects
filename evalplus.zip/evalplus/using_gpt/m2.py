import llm

debugging_prompt = '''
### Task Description:
the task is complete this:
```python
{task}
```
then it should pass the test cases :
```python
{cases}
```

### Current Code Draft:
#### current code
```python
{code}
```
#### current idea
- {idea}

### output of the code:
#### stdout
- {stdout}
#### error message
- {error_message}

### Specific Questions or Areas of Concern:
- {specific_task}
'''

def get_error(code):
    # This function should execute the code and return stdout and error messages
    # Implement this function based on your execution environment
    pass

def interact_with_llm(prompt, api_key, model="gpt-3.5-turbo"):
    # Function to interact with the language model using the Chat API
    response = openai.ChatCompletion.create(
        model=model,
        messages=[
            {"role": "user", "content": prompt}
        ],
        api_key=api_key
    )
    return response.choices[0].message['content'].strip()

def main():
    # API key for OpenAI (replace with your actual API key)
    api_key = "your-api-key"

    # Define the task for the language model
    task_prompt = "Write a Python function to calculate the factorial of a number."

    # Ask the language model to write code
    code = interact_with_llm(task_prompt, api_key)

    # Get stdout and error message
    stdout, error_message = get_error(code)

    if error_message:
        # If there's an error, send information back to the language model for debugging

        corrected_code = interact_with_llm(debugging_prompt, api_key)
        return corrected_code
    else:
        # If there's no error, return the final code
        return code

if __name__ == "__main__":
    final_code = main()
    print(final_code)
