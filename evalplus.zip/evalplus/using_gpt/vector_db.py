from langchain.vectorstores import FAISS
from langchain.docstore import InMemoryDocstore
from langchain.embeddings import HuggingFaceEmbeddings

# Define your embedding model
embeddings_model = HuggingFaceEmbeddings()
# Initialize the vectorstore as empty
import faiss

embedding_size = 768
index = faiss.IndexFlatL2(embedding_size)
vectorstore = FAISS(embeddings_model.embed_query, index, InMemoryDocstore({}), {})


sample_question_32 = '''import math

def evaluate_polynomial_at_point(coefficients: list, point: float) -> float:
    """
    Evaluates a polynomial with given coefficients at a specified point.

    Parameters:
    - coefficients (list): Coefficients of the polynomial [c0, c1, c2, ..., cn].
    - point (float): The point at which to evaluate the polynomial.

    Returns:
    float: The result of the polynomial evaluation at the specified point.
    """
    return sum([coeff * math.pow(point, i) for i, coeff in enumerate(coefficients)])


def find_single_zero(coefficients: list) -> float:
    """
    Finds a single zero of a polynomial with given coefficients.

    The function returns only one zero point, even if multiple zeros exist.
    It assumes that the input list of coefficients has an even number of elements,
    with the largest non-zero coefficient, ensuring a guaranteed solution.

    Examples:
    >>> round(find_single_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_single_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0

    Parameters:
    - coefficients (list): Coefficients of the polynomial [c0, c1, c2, ..., cn].

    Returns:
    float: The zero point of the polynomial.
    """
    '''
sample_solution_32 ='''
    'reasoning': 
    One possible way is to use the binary search-like approach for refining the interval to converge to a zero. This is a standard technique for narrowing down the search space

    'python solution':
    ```python
    import math

def evaluate_polynomial_at_point(coefficients: list, point: float) -> float:
    """
    Evaluates a polynomial with given coefficients at a specified point.

    Parameters:
    - coefficients (list): Coefficients of the polynomial [c0, c1, c2, ..., cn].
    - point (float): The point at which to evaluate the polynomial.

    Returns:
    float: The result of the polynomial evaluation at the specified point.
    """
    return sum([coeff * math.pow(point, i) for i, coeff in enumerate(coefficients)])

def find_single_zero(coefficients: list) -> float:
    """
    Finds a single zero of a polynomial with given coefficients.

    The function returns only one zero point, even if multiple zeros exist.
    It assumes that the input list of coefficients has an even number of elements,
    with the largest non-zero coefficient, ensuring a guaranteed solution.

    Examples:
    >>> round(find_single_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_single_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0

    Parameters:
    - coefficients (list): Coefficients of the polynomial [c0, c1, c2, ..., cn].

    Returns:
    float: The zero point of the polynomial.
    """
    begin, end = -1.0, 1.0

    # Expand the interval until it encompasses a region with a zero
    while evaluate_polynomial_at_point(coefficients, begin) * evaluate_polynomial_at_point(coefficients, end) > 0:
        begin *= 2.0
        end *= 2.0

    # Refine the interval using a binary search-like approach
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if evaluate_polynomial_at_point(coefficients, center) * evaluate_polynomial_at_point(coefficients, begin) > 0:
            begin = center
        else:
            end = center

    return begin
'''
sample_question_129 = '''Assume given a coding question, you need to analyze how to solve this coding question, including the algorithm needed, math equation needed, core idea, and etc. Now solve this question: def find_min_lex_path(grid, k):
    """
    Finds the minimum lexicographic path of length k in a grid.

    Args:
        grid (list of lists of int): A square grid of size N x N, where N >= 2,
            and each cell contains a unique integer in the range [1, N * N].
        k (int): The length of the path, where k >= 1.

    Returns:
        list of int: A list of the values on the cells that the minimum
            lexicographic path goes through. The list has length k and starts
            and ends with 1.

    Raises:
        ValueError: If grid is not a square or contains invalid values.
        ValueError: If k is not a positive integer or exceeds N * N.
'''
sample_solution_129 ='''
    'reasoning': 
    One possible way is to use  breadth-first search (BFS) algorithm, which explores the grid level by level, starting from the cells with value 1. For each cell, the algorithm stores the current path and the remaining steps. The algorithm stops when it finds a path that reaches the bottom right corner with exactly k steps, or when it exhausts all the possible paths.

    'python solution':
    ```python
def find_min_lex_path(grid, k):
    # check if the grid is valid
    if not grid or not grid[0]:
        raise ValueError("Invalid grid")
    n = len(grid)
    m = len(grid[0])
    if n < 2 or m < 2:
        raise ValueError("Grid size must be at least 2 x 2")
    if k < 1 or k > n * m:
        raise ValueError("Path length must be between 1 and N * M")

    # find the cells with value 1 and add them to the queue
    queue = []
    for i in range(n):
        for j in range(m):
            if grid[i][j] == 1:
                queue.append(((i, j), [1], k - 1)) # cell, path, remaining steps

    # explore the grid level by level using BFS
    while queue:
        cell, path, steps = queue.pop(0)
        i, j = cell
        # if the path reaches the bottom right corner with exactly k steps, return it
        if i == n - 1 and j == m - 1 and steps == 0:
            return path
        # otherwise, explore the four neighbors of the current cell
        for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            ni = i + di
            nj = j + dj
            # check if the neighbor is valid and has equal or smaller value
            if 0 <= ni < n and 0 <= nj < m and grid[ni][nj] <= grid[i][j]:
                # copy the current path and append the neighbor value
                new_path = path[:]
                new_path.append(grid[ni][nj])
                # add the neighbor cell, the new path, and the remaining steps to the queue
                queue.append(((ni, nj), new_path, steps - 1))

    # if no path is found, return None
    return None
```
'''
sample_question_bank = {}
sample_question_bank[sample_question_32] = sample_solution_32
sample_question_bank[sample_question_129] = sample_solution_129
vectorstore.add_texts([question for question in sample_question_bank.keys()])

def vectorsearch(docstore, index_ids):
    #for key, value in vectorstore.index_to_docstore_id.items():
    #print(key, value)
    #print(value, vectorstore.docstore.search(value))
    #print('\n')
    record = {}
    for key, value in index_ids.items():
        #print(key, value)
        #print(value, docstore.search(value))
        #print('\n')
        record[value] = docstore.search(value)
    return record
#record = vectorsearch(vectorstore.docstore, vectorstore.index_to_docstore_id)  
#record

#user_query = "import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n"
#search_result = vectorstore.similarity_search_with_score(user_query)[0]
#sample_question_search, score = search_result[0].page_content, 1 - search_result[1]
#print(sample_question_search)
#print(score)
#experience = sample_question_bank[sample_question_search]
#print(experience)
def experience_search(user_query):
    search_result = vectorstore.similarity_search_with_score(user_query)[0]
    sample_question_search, score = search_result[0].page_content, 1 - search_result[1]
    print(sample_question_search)
    print(score)
    experience = sample_question_bank[sample_question_search]
    print(experience)
    return sample_question_search, experience

experience_search("\ndef minPath(grid, k):\n    \"\"\"\n    Given a grid with N rows and N columns (N >= 2) and a positive integer k, \n    each cell of the grid contains a value. Every integer in the range [1, N * N]\n    inclusive appears exactly once on the cells of the grid.\n\n    You have to find the minimum path of length k in the grid. You can start\n    from any cell, and in each step you can move to any of the neighbor cells,\n    in other words, you can go to cells which share an edge with you current\n    cell.\n    Please note that a path of length k means visiting exactly k cells (not\n    necessarily distinct).\n    You CANNOT go off the grid.\n    A path A (of length k) is considered less than a path B (of length k) if\n    after making the ordered lists of the values on the cells that A and B go\n    through (let's call them lst_A and lst_B), lst_A is lexicographically less\n    than lst_B, in other words, there exist an integer index i (1 <= i <= k)\n    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have\n    lst_A[j] = lst_B[j].\n    It is guaranteed that the answer is unique.\n    Return an ordered list of the values on the cells that the minimum path go through.\n\n    Examples:\n\n        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3\n        Output: [1, 2, 1]\n\n        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1\n        Output: [1]\n    \"\"\"\n")