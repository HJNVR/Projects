from getprompt import get_prompt,get_taskid
from gettestcase import get_test_case
from modify import modify_code_using_testcases
from evalplus.data import write_jsonl
import json
def get_solution(p:int):
    prompt = get_prompt(p)
    #remove the test case lines in the code
    testcases = get_test_case(prompt)
    code = '#TODO'
    finalecode = modify_code_using_testcases(prompt,code,testcases,p=p)    
    if finalecode=='failed to solve the issue':
        print(f'{p},failed\n')
    else:
        print(f'{p},succeed\n')
    return finalecode

if __name__=='__main__':
    '''samples = [
        dict(task_id=get_taskid(i),prompt=get_solution(i))
        for i in range(164)
    ]
    write_jsonl("gpt35_humaneval.jsonl", samples)'''
    from faliure import faliure
    for i in faliure:
        for j in range(5):
            with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log_gpt4/{i}.md','a') as file:
                print('='*20,file=file)
            a = {}
            try:
                a['solution']=get_solution(i)
                a['task_id']=get_taskid(i)
                if a['solution'] != 'failed to solve the issue':
                    with open('temp_0110', 'a') as fp:
                        fp.write((json.dumps(a) + "\n"))
                    with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log_gpt4/{i}.md','a') as file:
                        print('='*20,file=file)
                        print(f'succeed here in round {j}',file=file)
                    break
                    
            except:
                print('fail one times')
                with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log_gpt4/{i}.md','a') as file:
                    print('='*20,file=file)
                    print(f'failed here in round {j}',file=file)
                pass
            with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log_gpt4/{i}.md','a') as file:
                print('='*20,file=file)
