from geterror import get_error
from llm import gpt35
import re
from gettestcase import get_test_case
from getprompt import get_prompt
def parse_code_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"```python\n(.*)\n```"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(1)
        # return a dictionary with the key "code" and the value as the code
        return {"code": code}
    # if there is no match, return None
    else:
        return {"code": '# the following code may contain some error!\n'+string}

systemprompt = '''
your are a helpful assistant helping user modify their code by adding some print lines in to the code , so that the user can easily understand which part of their code is working well and which part has problem.
user will give you task , draft , testcases , and the standerd out , error messages for refer .
you need considering them together to give reply , in your reply , there should be a short analysis about the how the print works . then the code draft added the print lines . in this format:
#reply
##analysis
YOUR_ANALYSIS_HERE
##modified code draft
```python
YOUR_MODIFIED_CODE_DRAFT
```
attention! you don't need to fix the error code , just add print line to help user understand their own code . 
'''

uesrprompt = '''
here is the info you need to analysis and modify the code
the task is complete this:
```python
{prompt}
```
here is the draft file:
```python
{exctuable}
```
based on the task , it should be able to pass the cases:
```python
{cases}
```
i paste the test cases to the bottom of the draft file and run you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
'''

rootmessage = [{"role":"system","content":systemprompt}]

def add_print(prompt,code,testcases):
    e,o = get_error(code)
    if e=='':
        return code
    cases = ''
    for t in testcases['assert lines']:
        cases += t+'\n'
    quary = uesrprompt.format(
        prompt = prompt,
        exctuable = code,
        cases = cases,
        error = e,
        out=o
    )
    message = {
            "role":"user",
            "content":quary
        }
    answer = gpt35((rootmessage+[message]))
    code = parse_code_block(answer[0]['content'])['code']
    return code

if __name__=='__main__':
    prompt = get_prompt(129)
    code = '''def minPath(grid, k):
    N = len(grid)
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]  # right, left, down, up
    visited = [[False]*N for _ in range(N)]
    paths = []

    def dfs(i, j, path):
        if len(path) == k:
            paths.append(path[:])
            return
        for dx, dy in directions:
            x, y = i + dx, j + dy
            if 0 <= x < N and 0 <= y < N and not visited[x][y]:
                visited[x][y] = True
                dfs(x, y, path + [grid[x][y]])
                visited[x][y] = False

    for i in range(N):
        for j in range(N):
            visited[i][j] = True
            dfs(i, j, [grid[i][j]])
            visited[i][j] = False

    return min(paths)

# Test the function
assert minPath([[1,2,3], [4,5,6], [7,8,9]], 3)==[1,2,1]  # Output: [1, 2, 1]
assert minPath([[5,9,3], [4,1,6], [7,8,2]], 1)==[1]  # Output: [1]'''
    testcases = get_test_case(prompt)
    print(prompt)
    print('='*208)
    print(add_print(prompt,code,testcases))
    
