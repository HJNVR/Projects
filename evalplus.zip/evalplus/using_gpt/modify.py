from geterror import get_error
import sys
#from ..draft import parse_code_block,debug_in_rounds
from getprompt import get_prompt
from gettestcase import get_test_case
from llm import gpt35, gpt4
import re
def parse_code_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"```python\n(.*)\n```"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(1)
        # return a dictionary with the key "code" and the value as the code
        return {"code": code}
    # if there is no match, return None
    else:
        return {"code": '# the following code may contain some error!\n'+string}

systemprompt = '''
your are a helpful assistant helping user modify their code .
user will give you task , draft , testcases , and the standerd out , error messages for refer .
you need considering them together to give reply , in your reply , shere should be a short analysis about the error reason . then the modified code draft . in this format:
#reply
##analysis
YOUR_ANALYSIS_HERE
##modified code draft
```python
YOUR_MODIFIED_CODE_DRAFT
```
attention! there should not be any ASSERT out side of comment , because when running , the testcases will be paste automatically to the bottom of the code 
'''

uesrprompt = '''
here is the info you need to analysis and modify the code
the task is complete this:
```python
{prompt}
```
here is the draft file:
```python
{exctuable}
```
based on the task , it should be able to pass the cases:
```python
{cases}
```
i paste the test cases to the bottom of the draft file and run you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
'''

rootmessage = [{"role":"system","content":systemprompt}]

def modify_code_using_testcases(prompt,exectuable,testcases,loops = 10,p=1):
    i = p
    cases = ''
    for t in testcases['assert lines']:
        cases += t+'\n'
    with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log/{i}.md','a') as file:
        print('#prompt\n',prompt,file=file)
        print('#testlines\n',cases,file=file)
    for _ in range(loops):
        error,out = get_error(exectuable+'\n'+cases)
        if error == '':
            #print(f'{}')
            return exectuable
        quary = uesrprompt.format(
            prompt = prompt,
            exctuable = exectuable,
            cases = cases,
            error = error,
            out=out
        )
        message = {
            "role":"user",
            "content":quary
        }
        with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log/{i}.md','a') as file:
            print('#userquery\n',quary,file=file)
        answer = gpt4((rootmessage+[message]))
        with open(f'/data0/panguchain/liyusu/panguchain/evalplus/all_log/{i}.md','a') as file:
            #print('#userquery\n',quary,file=file)
            print('#gpt answer\n',answer[0]['content'],file=file)
        exectuable = parse_code_block(answer[0]['content'])['code']
        #exectuable = debug_in_rounds(exectuable,loops=1)
    return 'failed to solve the issue'
        
if __name__=='__main__':
    prompt = get_prompt(129)
    testcases = get_test_case(prompt)
    code = '#TODO'
    print(modify_code_using_testcases(prompt,code,testcases))

