class Solution:
    def findMedianSortedArrays(self, nums1: list[int], nums2: list[int]) -> float:
        m = len(nums1)
        n = len(nums2)
        if (m+n) % 2 == 0:
            return self.from_even(nums1,nums2)
        else:
            return self.from_odd(nums1,nums2)
    def from_even(self,nums1,nums2):
        m = len(nums1)
        n = len(nums2)
        x1 = int((m+n)/2)
        x2 = int(x1-1)
        return (self.Num(x2,nums1,nums2) + self.Num(x1,nums1,nums2))/2
    def from_odd(self,nums1,nums2):
        m = len(nums1)
        n = len(nums2)
        x = int((m+n-1)/2)
        return self.Num(x,nums1,nums2)
    def Num(self,x,nums1,nums2):
        m = len(nums1)
        n = len(nums2)
        num1 = int(x*m/(m+n))
        num2 = int(x*n/(m+n))
        if num1+num2 == 0:
            sorted = nums1[:int(x+1)]+nums2[:int(x+1)]
            sorted.sort()
            return sorted[x]
        else:
            if nums1[num1]<=nums2[num2]:
                x = x-num1
                nums1 = nums1[num1:]
                return self.Num(x,nums1,nums2)
            else:
                x = x - num2
                nums2 = nums2[num2:]
                return self.Num(self,x,nums1,nums2)

print(Solution().findMedianSortedArrays([1,2],[3,4]))

if __name__=='__name__':
    print(Solution().findMedianSortedArrays([1,2],[3,4]))
