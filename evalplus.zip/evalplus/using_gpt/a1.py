#similar to agents.py , change get case to get test1
from getprompt import get_prompt,get_taskid
#from gettestcase import get_test_case
from gettest1 import get_test_case
#from modify import modify_code_using_testcases
from m1 import m1
from evalplus.data import write_jsonl
from faliure import faliure
import json
def get_solution(p:int):
    prompt = get_prompt(p)
    #remove the test case lines in the code
    testcases = get_test_case(prompt)
    code = '#TODO'
    finalecode = m1(prompt,code,testcases)
    if finalecode=='failed to solve the issue':
        print(f'{p},failed\n')
    else:
        print(f'{p},succeed\n')
    return finalecode

if __name__=='__main__':
    '''samples = [
        dict(task_id=get_taskid(i),prompt=get_solution(i))
        for i in range(164)
    ]
    write_jsonl("gpt35_humaneval.jsonl", samples)'''
    for i in range(1,2):
        for _ in range(5):
            a = {}
            try:
                a['solution']=get_solution(i)
                a['task_id']=get_taskid(i)
                if a['solution'] != 'failed to solve the issue':
                    with open('tempgpt4', 'a') as fp:
                        fp.write((json.dumps(a) + "\n"))
                    break
            except Exception as e:
                print(e)
                print('fail one times')
                pass
