from geterror import get_error
from llm import gpt35,gpt4 
from modify import parse_code_block
from getprompt import get_prompt
from gettest1 import get_test_case
from faliure import faliure
systemprompt = '''
your are a helpful assistant helping user modify their code .
user will give you task , draft , testcases , and the standerd out , error messages for refer .
you need considering them together to give reply , in your reply , there should be a short analysis about task it's self , the steps to solve the task , wether the draft code can approach the result , when there is error message , you also the error reason . then the modified code draft . in this format:
#reply
##analysis
YOUR_ANALYSIS_HERE
##modified code draft
```python
YOUR_MODIFIED_CODE_DRAFT
```
attention ! there should not be any ASSERT out side of comment , because when running , the testcases will be paste automatically to the bottom of the code . so your code always end with `\n    return ...`
'''


uesrprompt = '''
here is the info you need to analysis and modify the code
the task is complete this:
```python
{prompt}
```
here is the draft file:
```python
{exctuable}
```
based on the task , it should be able to pass the cases:
```python
{cases}
```
i paste the test cases to the bottom of the draft file and run you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
'''

rootmessage = [{"role":"system","content":systemprompt}]

def m1(prompt,code,testcases,loops = 10):
    with open('logm1_gpt4.md','a') as f:
        print(systemprompt,file=f)
    for _ in range(loops):
        error,out = get_error(code+'\n'+testcases)
        if error == '':
            #print(f'{}')
            return code
        quary = uesrprompt.format(
            prompt = prompt,
            exctuable = code,
            cases = testcases,
            error = error,
            out=out
        )
        message = {
            "role":"user",
            "content":quary
        }
        ###
        #ragmessage = [usermesseage_rag]+[systemmessage_rag]
        #answer = gpt35((rootmessage+ragmessage+[message]))
        answer = gpt4((rootmessage+[message]))
        #answer = gpt4((rootmessage+[message]))
        with open('logm1_gpt4.md','a') as f:
            print('-'*20,'\n',file=f)
            print(quary,file=f)
            print('-'*20,'\n',file=f)
            print(answer[0]['content'],file=f)
        code = parse_code_block(answer[0]['content'])['code']
        #exectuable = debug_in_rounds(exectuable,loops=1)
    return 'failed to solve the issue'

if __name__=='__main__':
    for j in faliure:
        with open('m1log1gpt4.md','a') as f:
            print('-'*20,f'\n{j}\n',file=f)
            print('-'*20,file=f)
        for i in range(5):
            with open('m1log1.md','a') as f:
                print(i,file=f)
                print('-'*20,file=f)
            prompt = get_prompt(j)
            #remove the test case lines in the code
            testcases = get_test_case(prompt)
            code = '#TODO'
            finalecode = m1(prompt,code,testcases)
            if finalecode!='failed to solve the issue':
                with open('m1log1.md','a') as f:
                    print('```python\n',file=f)
                    print(finalecode,file=f)
                    print('\n```\n',file=f)
                    print('finish',file=f)
                break 
            