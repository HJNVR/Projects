#define how to use a llm to debug a piece of code in a turns (default 10) , if after 10 turns there still not result , do no modification 

import traceback
import sys
sys.path.append('/data0/panguchain/liyusu/uniaigc/')
from uniaigc import generate
import re
def parse_code_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"```python\n(.*)\n```"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(1)
        # return a dictionary with the key "code" and the value as the code
        return {"code": code}
    # if there is no match, return None
    else:
        return {"code": '# the following code may contain some error!\n'+string}

def debug(code:str):
    try:
        print(1)
        exec(code) # try to execute the code
        print(1)
        #return code
    except Exception as e: # catch any exception
        error = traceback.format_exc() # get the traceback string
        prompt = f'user:\ni am doing some python task , here is his original code:\n```python\n{code}\n```\n and the error when i run the code :\n```\n{error}\n```\ncan you give modifacation?please give me the whole code with the format: \n```python\n{{your code here}}\n```\n\n===\nassistent:\n'
        answer = generate(prompt) 
        newcode = parse_code_block(answer)['code']
        return answer,newcode

def debuginloop(code,loops):
    try:
        exec(code)
        return code
    except:
        answer,code = debug(code)
        #print(answer)
    for _ in range(loops):
        try:
            answer,code = debug(code)
            #print(answer)
        except:
            return code
    return 'out of loop limitation'

'''def get_error(code):
    try:
        local_vars = {}
        exec(code, None, local_vars)
        return 'no error'
    except Exception as e: # catch any exception
        error = traceback.format_exc()
        return error'''

from geterror import execute_code
def debug_in_rounds(code,loops,logfilepath='lllm_debug_log_file'):
    '''logfile=\'lllm_debug_log_file\',modify in "/data0/panguchain/liyusu/panguchain/evalplus/draft.py"'''
    logfile = open(logfilepath,'a')
    for i in range(loops):
        error,out = execute_code(code)
        if error == '':
            return code
        prompt = f'user:\ni am doing some python task , here is his original code:\n```python\n{code}\n```\n and the error when i run the code :\n```\n{error}\n```\nyou can also refer the standerd out:\n```\n{out}\n```\ncan you give modifacation?please give me the whole code with the format: \n```python\n{{your code here}}\n```\n,you shoulden\'t change the testcases , neither sdd nor remove , i only need code , don\'t do explanation'
        answer = generate(prompt) 
        code = parse_code_block(answer)['code']
    error,out = execute_code(code)
    if error == '':
        return code
    return 'fail to finish debug'
code = '''from typing import List
def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
for i in range(len(numbers)):
    for j in range(i+1, len(numbers)):
        if abs(numbers[i] - numbers[j]) < threshold:
            return True
return False
'''

if __name__ == '__main__':
    print(debug_in_rounds(code,10))

