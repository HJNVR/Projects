from removeassert import removeassert
from modify_with_case import modify_code_using_testcases
from evalplus.data import get_human_eval_plus
from gettestcase import get_test_case
from draft import debug_in_rounds
import sys
sys.path.append('/data0/panguchain/liyusu/uniaigc/')
from uniaigc import generate
def get_prompt(x:int):
    for task_id,problem in get_human_eval_plus().items():
        if task_id.endswith('/'+str(x)):
            #print(task_id)
            code = problem['prompt']
            return code

def get_solution(p:int):
    prompt = get_prompt(p)
    firstcode = generate(prompt)
    #remove the test case lines in the code
    testcases = get_test_case(prompt)
    code = removeassert(prompt+firstcode)
    exectuable = debug_in_rounds(code,10)
    finalecode = modify_code_using_testcases(prompt,exectuable,testcases)
    return finalecode

if __name__=='__main__':
    p = 33
    print(get_prompt(p))
    print(get_solution(p))

