from pathlib import Path

tsr_base_dir = Path(__file__).parent
