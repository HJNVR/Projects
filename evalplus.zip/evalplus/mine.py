

def f(*args,**kargs):
    return ''

GEN_SOLUTION = f