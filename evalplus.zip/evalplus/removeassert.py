import sys
sys.path.append('/data0/panguchain/liyusu/uniaigc/')
from uniaigc import generate
from draft import parse_code_block

remove_assert_prompt = '''you are a skillful engineer , some of the code was modified by the intern , which means all the unit test is not reliable any more , please remove them all , and fix other obvious issue.
one of the code may be modified by the intern is:
```python
{code}
```
please give me your modification in the format
```python
#here is my modified code
your_code_here
```
this is a simple task , just give me the code , don\'t do explanation , remember add "```python\n" and "```" in your reply'''

def removeassert(code):
    prompt = remove_assert_prompt.format(code = code)
    answer = generate(prompt)
    return parse_code_block(answer)['code']

if __name__=='__main__':
    code = "def car_race_collision(n: int) -> int:\n    # Calculate the collision count using the formula n*(n-1)/2\n    return n*(n-1)//2\n\n\n# Testing the function with some test cases\nassert car_race_collision(1) == 0\nassert car_race_collision(2) == 1\nassert car_race_collision(3) == 3\nassert car_race_collision(4) == 6\nassert car_race_collision(5) == 10\nassert car_race_collision(6) == 15\nassert car_race_collision(7) == 21\nassert car_race_collision(8) == 28\nassert car_race_collision(9) == 36\nassert car_race_collision(10) == 45\n\nprint(\"All test cases passed!\")"
    print(code)
    print(removeassert(code))
    