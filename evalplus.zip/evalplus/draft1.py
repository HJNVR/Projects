#use language model and excuteable environment(pyhton) to modify code 

from draft import debuginloop
import json
from evalplus.data import get_human_eval_plus
json_list = [] # create an empty list to store the JSON objects
with open('/data0/panguchain/liyusu/panguchain/evalplus/samples_human_eval.jsonl') as file: # open the text file
    for line in file: # read the file line by line
        data = json.loads(line) # convert the JSON string to a Python dictionary
        json_list.append(data) # add the dictionary to the list
jsondict = {}
for j in json_list:
    jsondict[j['task_id']] = j['solution']

modified_samples = []
for task_id,problem in get_human_eval_plus().items():
    code = problem['prompt'] + jsondict[task_id]
    code = debuginloop(code=code,loops=10)
    if code!='out of loop limitation':
        with open('uniaigc_modified_evalplus.jsonl', 'a') as file:
            line = json.dumps({"task_id":task_id,"solution":code})
            file.write(line+'\n')
    else:
        print(task_id)