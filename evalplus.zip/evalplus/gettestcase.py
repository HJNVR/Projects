import sys
import re
sys.path.append('/data0/panguchain/liyusu/uniaigc/')
from uniaigc import generate
import json

templete = '''
user:
from the reference of the functions in the file i will give you , you can get the functions , and there demo input expect out put :
for example , if i give you this file:
```python
{demo_code}
```
you should reply this json:
```python
{demo_json}
```
please based on this code give me your json reply :
```python
{input_code}
```
===
assistent: 
sure, here is my reply :
```python
'''
demo_json = """
{"testcases":2,"assert lines":["assert has_close_elements([1.0, 2.0, 3.0], 0.5)==False,'test case 1'","assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)==True,'test case 2'"]}
"""
demo_code = '''
from typing import List
def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            if abs(numbers[i] - numbers[j]) < threshold:
                return True
    return False
'''

def parse_json_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"{(.*)}"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(0)
        # return a dictionary with the key "code" and the value as the code
        return json.loads(code)
    # if there is no match, return None
    else:
        return None

def get_test_case(inputcode):
    prompt = templete.format(demo_code=demo_code,demo_json=demo_json,input_code=inputcode)
    return parse_json_block(generate(prompt))

if __name__=='__main__':
    input_code = "\"\"\"\nWrite a python function to find smallest number in a list.\nassert smallest_num([10, 20, 1, 45, 99]) == 1\n\"\"\"\n"
    print(f'{input_code=}')
    print(f'{get_test_case(input_code)=}')