# 129 is a typical case suitable for debug and illustrate , 
# the prompt and some typical wrong completion will be listed here
import sys
sys.path.append('/data0/panguchain/liyusu/panguchain/evalplus/evalplus')
from evalplus.data import get_human_eval_plus
def get_prompt(x:int):
    for task_id,problem in get_human_eval_plus().items():
        if task_id.endswith('/'+str(x)):
            #print(task_id)
            code = problem['prompt']
            return code
        
def get_taskid(x:int):
    for task_id,problem in get_human_eval_plus().items():
        if task_id.endswith('/'+str(x)):
            #print(task_id)
            code = task_id
            return code    
prompt = get_prompt(129)
print(prompt)


#3.5 dialog history
#https://chat.openai.com/share/6845b1cc-1f48-4534-8b82-86ff0a8b7ee2

#gpt4 can pass without anything

prompt116 = get_prompt(116)
print(prompt116)