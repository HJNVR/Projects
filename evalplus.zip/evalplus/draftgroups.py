from metagpt.llm import LLM
from metagpt.roles import Role
from metagpt.actions import Action
from metagpt.provider.base_gpt_api import BaseGPTAPI
from metagpt.logs import logger
import sys
sys.path.append('/data0/panguchain/liyusu/uniaigc')
from uniaigc import generate
class OwnProvider(BaseGPTAPI):
    """here use humanprovider is a demo , we can use any api just replace that input part
    """
    PERFIX = 'OwnProvider , (llm is customized)'

    def ask(self, msg: str) -> str:
        logger.info("asking uniaigc")
        rsp = generate(msg)
        return rsp

    async def aask(self, msg: str, system_msgs: Optional[list[str]] = None) -> str:
        return self.ask(msg)

    def completion(self, messages: list[dict]):
        """dummy implementation of abstract method in base"""
        return []

    async def acompletion(self, messages: list[dict]):
        """dummy implementation of abstract method in base"""
        return []

    async def acompletion_text(self, messages: list[dict], stream=False) -> str:
        """dummy implementation of abstract method in base"""
        return []
class debugcode(Action):
    def __init__(self, name: str = "", context=None, llm: LLM = None):
        super().__init__(name, context, OwnProvider)

    async def run(self, instruction: str):
        prompt = self.PROMPT_TEMPLATE.format(instruction=instruction)
        #print('here ausjdnvicau')
        rsp = await self._aask(prompt)
        #print('here uxnc oudfnv')
        parsed = search_ticket.parse_code(rsp)
        #print ('here uhanosduvasiu')
        return parsed