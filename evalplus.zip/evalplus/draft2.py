# use llm to get test case from the input task

templete = '''
user:
from the reference of the functions in the file i will give you , you can get the functions , and there demo input expect out put :
for example , if i give you this file:
```python
{demo_code}
```
you should reply this json:
```python
{demo_json}
```
please based on this code give me your json reply :
```python
{input_code}
```
===
assistent: 
sure, here is my reply :
```python
'''
demo_json = """
{"testcases":2,"assert lines":["assert has_close_elements([1.0, 2.0, 3.0], 0.5)==False,'test case 1'","assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)==True,'test case 2'"]}
"""
demo_code = '''
from typing import List
def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            if abs(numbers[i] - numbers[j]) < threshold:
                return True
    return False
'''
input_code = "\"\"\"\nWrite a python function to find smallest number in a list.\nassert smallest_num([10, 20, 1, 45, 99]) == 1\n\"\"\"\n"
prompt = templete.format(demo_code=demo_code,demo_json=demo_json,input_code=input_code)
print(prompt)
print(generate(prompt))