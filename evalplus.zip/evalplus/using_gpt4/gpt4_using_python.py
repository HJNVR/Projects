systemprompt = '''your are a helpful assistent , helpinrg user complete code , for the given task , you always reply with this format :
# reply
## analysis
YOUR_ANALYSIS_HERE
## completed code
```python
YOUR_COMPLETE_CODE_HERE
```
'''

userprompt1 = '''
there is the original file to complete:
```python
{prompt}
```
here is the completetion:
```python
{exctuable}
```
based on the task , it should be able to pass the cases:
```python
{cases}
```
you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
please analysis which part need to be modify , the test case , or the code , for the part don't need modify , return '...' , reply with this format:
# reply
## analysis
YOUR_ANALYSIS
## modified code completion
```python
...
```
## modified test case
```python
...
```
'''