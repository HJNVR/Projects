import re
from llm import gpt35,gpt4
import json

from getprompt import get_prompt
import re
def parse_code_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"```python\n(.*)\n```"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(1)
        # return a dictionary with the key "code" and the value as the code
        return {"code": code}
    # if there is no match, return None
    else:
        return {"code": '# the following code may contain some error!\n'+string}
systemprompt = '''
you are a helpful assistent generate test cases in specific format for given task .
some times there is several testcases the other time maybe only one testcase , some times the test cases in the code is only for format introducing other time the test cases contain correct values and can be used directly.
for the function need to complete , please first analysis the test case one by one , tell the user howmany examples the task offer , what is the input and out put , which of them can be use as a testcase? why? then write a test function .
your reply should be in such format:
# reply
here is the code you can directly paste to the draft , used as a test
```python
# there is N cases in total Here is my analysis one by one:
# The 1st case can not(or can) be used
analysis_1 = """
the input is : ...
the out put is : ...
my analysis of this case : the analysis should be really detailed .
...
# Based on the analysis, here is the test functions(only contain the testcase can be used):
print(f'{{LEFT_SIDE_OF_TESTLINE_1=}}')
assert LEFT_SIDE_OF_TESTLINE_1==RIGHT_SIDE_OF_TESTLINE_1,analysis_1
...
print('all passed')
```'''
userprompt = '''do you understand the task:
```python
{prompt}
```
please give me test function taht i can paste directly under my code , don't implement the code
'''
prompt = '''import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
'''
reply = '''
# reply
here is the code you can directly paste to the draft , used as a test
```python
# there is 2 cases in total Here is my analysis one by one:
# The 1st case can be used
analysis_1 = """
the input is :[1, 2]
the out put is :-0.5
The function find_zero([1, 2]) should return -0.5 as it's the root of the equation f(x) = 1 + 2x , 1 + 2(-0.5) = 0"""
# The 2nd case can be used
analysis_2 = """
the input is :[-6, 11, -6, 1]
the out put is :1
The function find_zero([-6, 11, -6, 1]) return 1.0 as it's one of the roots of the equation f(x) = -6 + 11x - 6x^2 + x^3 , f(x) = (x - 1) * (x - 2) * (x - 3) , if x=1,2or3,f(x)=0
"""

# Based on the analysis, here is the test function:
print(f'{{round(find_zero([1, 2]), 2)=}}')
assert round(find_zero([1, 2]), 2) == -0.5,analysis_1
print(f'{{find_zero([-6, 11, -6, 1]), 2)=}}')
assert round(find_zero([-6, 11, -6, 1]), 2) == 1.0,analysis_2
print('all passed')
```
'''
m1 = {'role':'system','content':systemprompt}
m2 = {'role':'user','content':userprompt.format(prompt=prompt)}
m3 = {'role':'assistant','content':reply}

rootmessages35 = [m1,m2,m3]
rootmessages4 = [m1]
def get_test_case35(inputcode):
    messages35 = rootmessages35
    messages35.append({
        "role":"user",
        "content":userprompt.format(prompt = inputcode)
    })
    out35 = gpt35(messages35)
    return parse_code_block(out35[0]['content'])['code']

def get_test_case4(inputcode):
    messages4 = rootmessages4
    messages4.append({
        "role":"user",
        "content":userprompt.format(prompt = inputcode)
    })
    out4 = gpt4(messages4)
    return parse_code_block(out4[0]['content'])['code']

if __name__=='__main__':
    #from faliure import faliure
    for i in [81]:
        print(i)
        path = rf'C:\Users\l84300473\Desktop\evalplus\testcase_gpt1\{i}'
        with open(path,'w',encoding='utf-8') as f:
            print(i,file=f)
            #for _ in range(3):
            input_code = get_prompt(i)
            print('='*20,'\n',file=f)
            print(input_code,file=f)
            print('='*20,'\n',file=f)
            testcase = get_test_case4(input_code)
            print(testcase,file=f)
            print('='*20,'\n',file=f)
            testcase = get_test_case35(input_code)
            print(testcase,file=f)
            print('='*20,'\n',file=f)