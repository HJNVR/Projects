import json
from llm import gpt4 
from getprompt import get_taskid, get_prompt
import re
def parse_code_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"```python\n(.*)\n```"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    code = match.group(1)
    # return a dictionary with the key "code" and the value as the code
    return {"code": code}
    # if there is no match, return None
    #else:
    #    return {"code": '# the following code may contain some error!\n'+string}

'''def gpt4(message):
    completion = client.chat.completions.create(
        model="gpt-4-1106-preview",#"gpt-3.5-turbo",
        messages=message
    )
    return [{'role':completion.choices[0].message.role,'content':completion.choices[0].message.content}]'''


def get_solution(task):
    prompt = get_prompt(task)
    messages = [{'role':'user','content':prompt}]
    message =  gpt4(messages)
    try:
        with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log\{i}.md','a') as file:
            print(messages[0]['content'],file=file)
            print('\n-----\n',file=file)
            print(message[0]['content'],file=file)
    except:
         pass
    code = parse_code_block(message[0]['content'])
    return code['code']

if __name__=='__main__':
    '''samples = [
        dict(task_id=get_taskid(i),prompt=get_solution(i))
        for i in range(164)
    ]
    write_jsonl("gpt35_humaneval.jsonl", samples)'''

    for i in range(165):
        for j in range(5):
            with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log\{i}.md','a') as file:
                print('='*20,file=file)
            a = {}
            try:
                a['solution']=get_solution(i)
                a['task_id']=get_taskid(i)
                if a['solution'] != 'failed to solve the issue':
                    with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\gpt4', 'a') as fp:
                        fp.write((json.dumps(a) + "\n"))
                    with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log\{i}.md','a') as file:
                        print('='*20,file=file)
                        print(f'succeed here in round {j}',file=file)
                    break
                    
            except:
                print('fail one times')
                with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log\{i}.md','a') as file:
                    print('='*20,file=file)
                    print(f'failed here in round {j}',file=file)
                pass
            with open(rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log\{i}.md','a') as file:
                print('='*20,file=file)
