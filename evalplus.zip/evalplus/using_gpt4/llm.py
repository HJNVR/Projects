from openai import OpenAI
client = OpenAI(api_key='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')

def gpt4(message):
    completion = client.chat.completions.create(
        model="gpt-4-1106-preview",#"gpt-3.5-turbo",
        messages=message
    )
    return [{'role':completion.choices[0].message.role,'content':completion.choices[0].message.content}]

def gpt35(message):
    completion = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview"
        messages=message
    )
    return [{'role':completion.choices[0].message.role,'content':completion.choices[0].message.content}]

def printms(messages):
    print('\n'+'='*20+'\n')
    for m in messages:
        print(m['role'],':\n',m['content'],'\n')
    print('\n'+'='*20+'\n')

def gpt_changwang(message):
    return



if __name__=='__main__':
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Who won the world series in 2020?"},
        {"role": "assistant", "content": "The Los Angeles Dodgers won the World Series in 2020."},
        {"role": "user", "content": "Where was it played?"}
    ]
    printms(messages)
    print('gpt4:')
    messages4 = gpt4(messages)
    printms(messages4)
    print('gpt3.5:')
    printms(gpt35(messages))

    


