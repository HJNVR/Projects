import json
def get_wrong(path):
    j = json.load(open(path))
    wronglist = []
    for t in j['eval']:
        if j['eval'][t]['base'][0][0]!='success':
            wronglist.append(int(t[10:]))
    wronglist.sort()
    return wronglist
if __name__=='__main__':
    path = rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\gpt4_final_eval_results.json'
    fail= get_wrong(path)
    print(len(fail))
    print(fail)