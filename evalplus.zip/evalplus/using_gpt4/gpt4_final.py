from gpt4_systemprompt_parser import get_solution
from llm import gpt4 
from geterror import execute_code
from gettestcases import *
from llm import *
from getprompt import *
# Script to extract the code sections enclosed between ```python and ``` from a file content.
userprompt1 = '''
there is the original file to complete:
```python
{task}
```
here is the completetion:
```python
{code}
```
based on the task , it should be able to pass the cases:
```python
{testcases}
```
you can refer the standerd out 
```
{out}
```
and the error message:
```
{error}
```
please analysis which part need to be modify , the test case , or the code , for the part don't need modify , return '...' , reply with this format:
# reply
## analysis
YOUR_ANALYSIS
## modified code completion
```python
...
```
## modified test case
```python
...
```
'''

def extract_python_code(file_content):
    code_sections = []
    start_token = "```python"
    end_token = "```"

    # Splitting the file content into parts based on start_token
    parts = file_content.split(start_token)

    # Extracting the code sections from each part
    for part in parts[1:]:  # Starting from 1 to skip the first part before the first code section
        code_section = part.split(end_token)[0].strip()  # Extracting the code section before the end token
        code_sections.append(code_section)
    
    return code_sections

def form_prompt(n:int)->str:
    task,code,testcase = initinput(n)
    #print(code)
    e,o = execute_code(task+code+testcase)
    #print(task+code+testcase)
    #print(e)
    #print(o)
    prompt = userprompt1.format(
        task=task,
        code = code,
        testcases = testcase,
        out = o,
        error = e
    )
    #print(prompt)
    return prompt

def initinput(n):
    '''input n , out put task,code,testcase'''
    try:
        taskpath = rf'C:\Users\l84300473\Desktop\evalplus\testcase_gpt1\{n}'
        sections = []
        with open(taskpath,'r') as file:
            file_content = file.read()
            sections = file_content.split("====================")
        task = sections[1]
        #print(task)
        testcase = sections[2]
    except:
        #gettestcase
        path = rf'C:\Users\l84300473\Desktop\evalplus\testcase_gpt1\{n}'
        with open(path,'w',encoding='utf-8') as f:
            print(i,file=f)
            #for _ in range(3):
            input_code = get_prompt(n)
            print('='*20,'\n',file=f)
            print(input_code,file=f)
            print('='*20,'\n',file=f)
            testcase4 = get_test_case4(input_code)
            print(testcase4,file=f)
            print('='*20,'\n',file=f)
            testcase3 = get_test_case35(input_code)
            print(testcase3,file=f)
            print('='*20,'\n',file=f)
        task = input_code
        testcase = testcase4
    #print(testcase)
    codepath = rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log_systemprompt_parser\{n}.md'
    try:
        with open(codepath,'r') as file:
            file_content = file.read()
            sections = extract_python_code(file_content)
        code = sections[1]
    except:
        with open(codepath,'w',encoding='utf-8') as file:
            print('='*20,file=file)
            code=get_solution(n)
    return task,code,testcase

def gpt4complete(prompt):
    messages = [{'role':'user','content':prompt}]
    res = gpt4(messages)
    return res[0]['content']

def parser(res):
    sections = extract_python_code(res)
    code,test = sections
    x = 0
    if code != '...':
        x = 1
    elif test != '...':
        x = 2    
    return x,code,test

def modify(task,code,case,e,o,logfile = 'debug_log'):
    prompt = userprompt1.format(
        task=task,
        code = code,
        testcases = case,
        out = o,
        error = e
    )
    with open(logfile,'a') as f:
        print('\n',file=f)
        print('='*20,file=f)
        print('\n',file=f)
        print('prompt:\n',file=f)
        print(prompt,file=f)
    res = gpt4complete(prompt)
    with open(logfile,'a') as f:
        print('\n',file=f)
        print('='*20,file=f)
        print('\n',file=f)
        print('res:\n',file=f)
        print(res,file=f)
    return parser(res)

def debug_task_code_case(task,code,case,logfile = 'debug_log'):
    for i in range(10):
        e,o = execute_code(task+'\n'+code+'\n'+case)
        if e == '':
            with open(logfile,'a',encoding='utf-8') as f:
                print(f'succeed in round{i}:\n',file=f)
                print(f'```python\n{task+code+case}\n```',file=f)
            return task+code
        with open(logfile,'a') as f:
            print(f'round{i}:\n',file=f)
        x,m_code,m_case = modify(task,code,case,e,o,logfile = logfile)
        if x == 0 :
            return 'failed'
        if x == 1 :
            code = m_code
        if x == 2 :
            case = m_case

if __name__ == '__main__':
    testnum = [81]
    for i in testnum:
        try:
            task,code,case = initinput(i)
            logfile = rf'C:\Users\l84300473\Desktop\evalplus\using_gpt4\log_gpt4_final\gpt4_{i}.md'
            a = {}
            a['task_id'] = get_taskid(i)
            a['solution'] = debug_task_code_case(task,code,case,logfile = logfile)
            with open('gpt4_final_debug.jsonl','a') as f:
                f.write((json.dumps(a) + "\n"))
            print(f'finish {i}')
        except:
            print(f'{i}failed')



