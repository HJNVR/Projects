from evalplus.data import get_human_eval_plus
def get_prompt(x:int):
    for task_id,problem in get_human_eval_plus().items():
        if task_id.endswith('/'+str(x)):
            #print(task_id)
            code = problem['prompt']
            return code
        
def get_taskid(x:int):
    for task_id,problem in get_human_eval_plus().items():
        if task_id.endswith('/'+str(x)):
            #print(task_id)
            code = task_id
            return code    
        

if __name__=='__main__':
    print(get_prompt(1))