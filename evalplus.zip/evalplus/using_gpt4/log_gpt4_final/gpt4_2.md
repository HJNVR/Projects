succeed in round0:

```python


def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    integer_part = int(number)  # This extracts the integer part
    decimal_part = number - integer_part  # This calculates the decimal part
    return decimal_part# there is 1 case in total Here is my analysis one by one:
# The 1st case can be used
analysis_1 = """
the input is : 3.5
the output is : 0.5
my analysis of this case: the input is a positive floating number and the output is the decimal part of this number, which is correctly specified; therefore, this can be used as a test case directly.
"""

# Based on the analysis, here is the test function (only contain the testcase that can be used):
print(f'truncate_number(3.5)=', truncate_number(3.5))
assert truncate_number(3.5) == 0.5, analysis_1

print('all tests passed')
```
