import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import sys
sys.path.append("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\LLM")
from UniAIGC import UniAIGC
LLM = UniAIGC()

from langchain.chat_models import ChatOpenAI
from llm_compiler.llm_compiler import LLMCompiler
from src.utils.evaluation_utils import arun_and_time
from prompts.humaneval_prompt import planner_prompt_code_multi_1, output_prompt_code_multi_1, planner_prompt_code_multi_3, output_prompt_code_multi_3, planner_prompt_code_multi_5, output_prompt_code_multi_5
from agents.Coder import coder_1, coder_2, coder_3, coder_4, coder_5
from agents.Tester import tester
from agents.DiscussionHoster import discusshoster
from agents.Experimenter import experimenter

END_OF_PLAN = "<END_OF_PLAN>"
JOINNER_FINISH = "Finish"
JOINNER_REPLAN = "Replan"

# ******************************************************
agents = [coder_1, coder_2, coder_3, coder_4, coder_5, tester, experimenter,discusshoster]
# ******************************************************

import argparse
argparser = argparse.ArgumentParser()
argparser.add_argument(
    "--benchmark_name",
    type=str,
    required=True,
    help="benchmark name",
    choices=["humaneval"],
)
argparser.add_argument("--coder_num", type=int, default=1, help="number of coders")
argparser.add_argument("--store", type=str, required=True, help="store path")
argparser.add_argument("--api_key", type=str, required=True, help="openai api key")
args = argparser.parse_args()

def get_dataset(args):
    import json
    if args.benchmark_name =="humaneval":
        f = open ("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\benchmark\\humaneval_all_data.json", "r")
        data = json.loads(f.read())
    return data

def get_master_prompt(args):
    if args.benchmark_name =="humaneval":
        if args.coder_num == 1:return planner_prompt_code_multi_1, output_prompt_code_multi_1
        elif args.coder_num == 3:return planner_prompt_code_multi_3, output_prompt_code_multi_3
        elif args.coder_num == 5:return planner_prompt_code_multi_5, output_prompt_code_multi_5

def get_question_prompt(args):
    if args.benchmark_name =="humaneval":
        if args.coder_num == 1:return """Given the entry_point: {0}, I need Coder_1 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
        elif args.coder_num == 3:return """Given the entry_point: {0}, I need Coder_1, Coder_2, Coder_3 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
        elif args.coder_num == 5:return """Given the entry_point: {0}, I need Coder_1, Coder_2, Coder_3, Coder_4, Coder_5 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
CONFIGS = {
    "default_model": "gpt-3.5-turbo-1106", #"uniaigc",#
    "data": {},
    "benchmark_name": '',
    "coder_num": 1,
    "planner_prompt": '',
    "output_prompt": '',
    "max_replans": 1,
    "question_prompt": '',
    "store": ''
}

CONFIGS['data'] = get_dataset(args)
CONFIGS['planner_prompt'], CONFIGS['output_prompt']= get_master_prompt(args)
CONFIGS['question_prompt'] = get_question_prompt(args)
CONFIGS["coder_num"] = args.coder_num
CONFIGS['benchmark_name'] = args.benchmark_name
CONFIGS['store'] = args.store
#planner_llm = LLM
#llm = LLM
planner_llm = ChatOpenAI(
            model_name=CONFIGS["default_model"],
            openai_api_key=args.api_key,
            temperature=0,
            streaming=False,
        )
llm = ChatOpenAI(
            model_name=CONFIGS["default_model"],
            openai_api_key=args.api_key,
            temperature=0,
            streaming=False,
        )

#print(CONFIGS)
#configs = CONFIGS#get_configs(args)
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=3 --store="C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\experiment_result_log\\2024_1_8_result_uni_10times_1agents.txt"
#exit()
batch = 1
#import json
#f = open ("/data0/panguchain/huangjing/benchmark/human-eval/human_eval/all_data.json", "r")
#data = json.loads(f.read())
#print(len(data))

final_result = []
import asyncio
import time
async def main():
    start_time = time.time()
    # ['HumanEval/6', 'HumanEval/9', 'HumanEval/10', 'HumanEval/17', 'HumanEval/20', 'HumanEval/21', 'HumanEval/23', 'HumanEval/27']
    #len(CONFIGS['data'])
    for i in range(32, 33, batch):#163,len(CONFIGS['data']), batch):#[146,148,151,153,154,160,163]:#range(62,63,batch):
        octopus_agent = LLMCompiler(
        agents=agents,
        planner_llm=planner_llm,
        planner_example_prompt=CONFIGS['planner_prompt'],
        planner_example_prompt_replan=CONFIGS['planner_prompt'],
        planner_stop=[END_OF_PLAN],
        planner_stream=False,
        agent_llm=llm,
        joinner_prompt=CONFIGS['output_prompt'],
        joinner_prompt_final=None,
        max_replans=1,
        benchmark=False,
        batch=batch,
        total_data_len=len(CONFIGS['data']),
        current_q=CONFIGS['data'][f"HumanEval/{i}"]['prompt'],
        coder_num=CONFIGS['coder_num'],
        bench_mark_name=CONFIGS['benchmark_name'],
        store=CONFIGS['store']
        )
        
        question = ' '.join([CONFIGS['question_prompt'].format(CONFIGS['data'][key]['entry_point'], CONFIGS['data'][key]['prompt']) for key in dict(list(CONFIGS['data'].items())[i:i+batch]).keys()])
        async def one_iteration(question):
            result = await arun_and_time(octopus_agent.arun, question)
            return result
        result = await one_iteration(question)
        final_result.append(result)
        time.sleep(0)
    print("--- %s seconds ---" % (time.time() - start_time))
    return final_result

results = asyncio.get_event_loop().run_until_complete(main())
#print(results)
