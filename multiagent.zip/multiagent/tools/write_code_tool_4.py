import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import sys
sys.path.append("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\LLM")
from UniAIGC import UniAIGC
LLM = UniAIGC()
from .base import Tool

from openai import OpenAI
client = OpenAI(api_key='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')

async def writecode_4_35(code_questions):
    print("Coder_3 working ... ")
    #if 
    if '+sep+' in code_questions:
      code_questions_l = code_questions.split('+exp_sep+')
      variables = []

      for code_question in code_questions_l[:-1]:
          temp = code_question.split("+sep+")
          variables.append(temp)

      # access the variables by indexing the variables list
      CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
      _, prev_error_2, prev_codes_2, prev_out_2, prev_testcases_2, prev_analysis_2 = variables[1][0], variables[1][1], variables[1][2], variables[1][3], variables[1][4], variables[1][5]
      _, prev_error_3, prev_codes_3, prev_out_3, prev_testcases_3, prev_analysis_3 = variables[2][0], variables[2][1], variables[2][2], variables[2][3], variables[2][4],  variables[2][5]
      system_prompt = """You are a professional code assisstant.
  You will learn from previous attempts, including `previous_error` , `previous_python_solution`, `previous_standardout`, `previous_testcases` and `previous_analysis`
  Then gather all the insights from these attemps and generate one better python solution for a given coding question. 
  """
      user_prompt = """Now please learn from all these attemtps:
  Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
  Attempt 2. previous error: {error_2}, previous_python_solution: {codes_2}, `previous_standardout`: {out_2}, `previous_testcases`: {testcase_2}, `previous_analysis`: {analysis_2}
  Attempt 3. previous error: {error_3}, previous_python_solution: {codes_3}, `previous_standardout`: {out_3}, `previous_testcases`: {testcase_3}, `previous_analysis`: {analysis_3}
  then generate one better python solution for this question: {code_question}
  You need to write certain reasoning, and `python_solution`. 
  You must start your python_solution with ```python""".format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
             error_2=prev_error_2, codes_2=prev_codes_2, out_2 = prev_out_2, testcase_2=prev_testcases_2, analysis_2=prev_analysis_2,
             error_3=prev_error_3, codes_3=prev_codes_3, out_3 = prev_out_3, testcase_3=prev_testcases_3, analysis_3=prev_analysis_3,
            code_question=CURRENT_CODE_QUESTION)
      completion = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
            #{"role": "assistant", "content": sample_solution},
            #{"role": "user", "content": f"Help me to write python solution for this coding quesion: {code_questions}. Make sure the python solution is in ```python code snippet."},
        ],
        temperature=2
        )
      result = completion.choices[0].message.content
      with open('/data0/panguchain/pgpts/agents/all_logs/coder_3_prompt.txt', 'a') as f:
        f.write(user_prompt)
        f.write('\n======\n')
      #result = LLM(prompt_final)
      try:
        result = extract_python_code(result)[0]
      except:
        result = '```python\n'+result + '```'
        result = extract_python_code(result)[0]
    #========================================================================================
    else:
      system_prompt = """Your profile is: 
    Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
    Years of experience: 3
    Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
    Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas.
    
    As an algorithm engineer, you possess expertise in using all kinds of algorithm to write PYTHON codes.
    Please solve the given coding question. Make sure that the solution is always correct. You MUST use Python to solve the coding question.
    Your response MUST be a dictionary with keys "reasoning" and "python_solution", which correspond to the reasoning and Python implementations of the function.
    You MUST only respond in the format as described below. DO NOT RESPOND WITH ANYTHING ELSE. ADDING ANY OTHER EXTRA NOTES THAT VIOLATE THE RESPONSE FORMAT IS BANNED. START YOUR PYTHON SOLUTION WITH ```python.
    [response format]:
    "reasoning": "Analysis of solving the coding question, including the algorithm needed, math equation need, core idea, and potential error to avoid, and etc."
    "python solution":
    ```python
    Python implementation of the function. Ensure the output of the function aligns with its specified return type. YOU MUST KEPP CLEAN INDENATION AND INCLUDE NECESSARY IMPORT. for example: `import math`, `from typing import List`, and etc."""
   
      sample_question = '''def coin_change(coins, amount):
  \"\"\"
  Finds the minimum number of coins needed to make a given amount of change using a greedy algorithm.

  Parameters:
  coins (list): A list of coin denominations in cents.
  amount (int): The amount of change in cents.

  Returns:
  int: The minimum number of coins used, or -1 if the change cannot be made.
  \"\"\"'''
      sample_solution = '''"reasoning": "The algorithm needed: The function uses a greedy algorithm that sorts the coins in descending order and picks the largest ones first to make the change.
The math equation needed: The function uses the integer division operation (//) to find how many coins of each denomination can fit into the remaining amount.
The core idea: The function tries to use the fewest coins possible by using the largest coins first and then the smaller ones.
The potential error to avoid: The function may not find the optimal solution in some cases, so it should check the coin order and the change feasibility before using the greedy algorithm.",  
    "python solution":
    ```python
    # Python function for coin change problem using greedy algorithm
def coin_change(coins, amount):
  # Sort the coin denominations in descending order
  coins.sort(reverse=True)
  # Initialize the number of coins used
  num_coins = 0
  # Loop through the coin denominations
  for coin in coins:
    # Check how many times the coin can fit into the remaining amount
    count = amount // coin
    # Add that number of coins to the total number of coins used
    num_coins += count
    # Subtract that amount from the remaining amount
    amount -= count * coin
    # Break the loop if the remaining amount is zero
    if amount == 0:
      break
  # Return the number of coins used, or -1 if the change cannot be made
  if amount > 0:
    return -1
  else:
    return num_coins
    ```'''
      completion = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": sample_question},
            {"role": "assistant", "content": sample_solution},
            {"role": "user", "content": f"Help me to write python solution for this coding quesion: {code_questions}. Make sure the python solution is in ```python code snippet."},
        ],
        temperature=2
        )
      result = completion.choices[0].message.content
      try:
        result = extract_python_code(result)[0]
      except:
        result = '```python\n'+result + '```'
        result = extract_python_code(result)[0]
      with open('/data0/panguchain/pgpts/agents/all_logs/coder_3.txt', 'a') as f:
        f.write(result)
        f.write('\n======\n')
    return result
async def writecode_4(code_questions):
    print("Coder_4 working ... ")
    #if 
    if '+sep+' in code_questions:
      code_questions_l = code_questions.split('+exp_sep+')
      variables = []

      for code_question in code_questions_l[:-1]:
          temp = code_question.split("+sep+")
          variables.append(temp)

      if len(variables) == 5:
        # access the variables by indexing the variables list
        CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
        _, prev_error_2, prev_codes_2, prev_out_2, prev_testcases_2, prev_analysis_2 = variables[1][0], variables[1][1], variables[1][2], variables[1][3], variables[1][4], variables[1][5]
        _, prev_error_3, prev_codes_3, prev_out_3, prev_testcases_3, prev_analysis_3 = variables[2][0], variables[2][1], variables[2][2], variables[2][3], variables[2][4],  variables[2][5]
        _, prev_error_4, prev_codes_4, prev_out_4, prev_testcases_4, prev_analysis_4 = variables[3][0], variables[3][1], variables[3][2], variables[3][3], variables[3][4], variables[3][5]
        _, prev_error_5, prev_codes_5, prev_out_5, prev_testcases_5, prev_analysis_5 = variables[4][0], variables[4][1], variables[4][2], variables[4][3], variables[4][4],  variables[4][5]
        prompt_final = """You are a professional code assisstant.
  You will learn from previous attempts, including `previous_error` , `previous_python_solution`, `previous_standardout`, `previous_testcases` and `previous_analysis`
  Then gather all the insights from these attemps and generate one better python solution for a given coding question. 
  Now please learn from all these attemtps:
  Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
  Attempt 2. previous error: {error_2}, previous_python_solution: {codes_2}, `previous_standardout`: {out_2}, `previous_testcases`: {testcase_2}, `previous_analysis`: {analysis_2}
  Attempt 3. previous error: {error_3}, previous_python_solution: {codes_3}, `previous_standardout`: {out_3}, `previous_testcases`: {testcase_3}, `previous_analysis`: {analysis_3}
  Attempt 4. previous error: {error_4}, previous_python_solution: {codes_4}, `previous_standardout`: {out_4}, `previous_testcases`: {testcase_4}, `previous_analysis`: {analysis_4}
  Attempt 5. previous error: {error_5}, previous_python_solution: {codes_5}, `previous_standardout`: {out_5}, `previous_testcases`: {testcase_5}, `previous_analysis`: {analysis_5}
  then generate one better python solution for this question: {code_question}
  You need to write certain reasoning, and `python_solution`. 
  You must start your python_solution with ```python
  """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
             error_2=prev_error_2, codes_2=prev_codes_2, out_2 = prev_out_2, testcase_2=prev_testcases_2, analysis_2=prev_analysis_2,
             error_3=prev_error_3, codes_3=prev_codes_3, out_3 = prev_out_3, testcase_3=prev_testcases_3, analysis_3=prev_analysis_3,
             error_4=prev_error_4, codes_4=prev_codes_4, out_4 = prev_out_4, testcase_4=prev_testcases_4, analysis_4=prev_analysis_4,
             error_5=prev_error_5, codes_5=prev_codes_5, out_5 = prev_out_5, testcase_5=prev_testcases_5, analysis_5=prev_analysis_5,
            code_question=CURRENT_CODE_QUESTION)
      elif len(variables) == 3:
         # access the variables by indexing the variables list
        CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
        _, prev_error_2, prev_codes_2, prev_out_2, prev_testcases_2, prev_analysis_2 = variables[1][0], variables[1][1], variables[1][2], variables[1][3], variables[1][4], variables[1][5]
        _, prev_error_3, prev_codes_3, prev_out_3, prev_testcases_3, prev_analysis_3 = variables[2][0], variables[2][1], variables[2][2], variables[2][3], variables[2][4],  variables[2][5]
        prompt_final = """You are a professional code assisstant.
  You will learn from previous attempts, including `previous_error` , `previous_python_solution`, `previous_standardout`, `previous_testcases` and `previous_analysis`
  Then gather all the insights from these attemps and generate one better python solution for a given coding question. 
  Now please learn from all these attemtps:
  Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
  Attempt 2. previous error: {error_2}, previous_python_solution: {codes_2}, `previous_standardout`: {out_2}, `previous_testcases`: {testcase_2}, `previous_analysis`: {analysis_2}
  Attempt 3. previous error: {error_3}, previous_python_solution: {codes_3}, `previous_standardout`: {out_3}, `previous_testcases`: {testcase_3}, `previous_analysis`: {analysis_3}
  then generate one better python solution for this question: {code_question}
  You need to write certain reasoning, and `python_solution`. 
  You must start your python_solution with ```python
  """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
             error_2=prev_error_2, codes_2=prev_codes_2, out_2 = prev_out_2, testcase_2=prev_testcases_2, analysis_2=prev_analysis_2,
             error_3=prev_error_3, codes_3=prev_codes_3, out_3 = prev_out_3, testcase_3=prev_testcases_3, analysis_3=prev_analysis_3,
            code_question=CURRENT_CODE_QUESTION)
      elif len(variables) == 1:
         # access the variables by indexing the variables list
        CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
        prompt_final = """You are a professional code assisstant.
  You will learn from previous attempts, including `previous_error` , `previous_python_solution`, `previous_standardout`, `previous_testcases` and `previous_analysis`
  Then gather all the insights from these attemps and generate one better python solution for a given coding question. 
  Now please learn from all these attemtps:
  Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
  then generate one better python solution for this question: {code_question}
  You need to write certain reasoning, and `python_solution`. 
  You must start your python_solution with ```python
  """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
            code_question=CURRENT_CODE_QUESTION)
      with open('/data0/panguchain/pgpts/agents/all_logs/coder_4_prompt.txt', 'a') as f:
        f.write(prompt_final)
        f.write('\n======\n')
      result = LLM(prompt_final)
      try:
        result = extract_python_code(result)[0]
      except:
        result = '```python\n'+result + '```'
        result = extract_python_code(result)[0]

    #========================================================================================
    else:
        prompt_final = """Your profile is: 
        Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Stanford University 
        Years of experience: 3 Coding awards: Runner-up of the Kaggle Competition 2022, Lead developer of the app SmartHome, Author of the book AI for Everyone 
        Personality: Curious, analytical, ambitious, and collaborative. Loves to explore new technologies and apply them to real-life scenarios. Enjoys working with diverse teams and learning from different perspectives.
            
        As an algorithm engineer, you possess expertise in using all kinds of algorithm to write PYTHON codes.
        Please solve the given coding question. Make sure that the solution is always correct. You MUST use Python to solve the coding question.
        Your response MUST be a dictionary with keys "reasoning" and "python_solution", which correspond to the reasoning and Python implementations of the function.
        You MUST only respond in the format as described below. DO NOT RESPOND WITH ANYTHING ELSE. ADDING ANY OTHER EXTRA NOTES THAT VIOLATE THE RESPONSE FORMAT IS BANNED. START YOUR PYTHON SOLUTION WITH ```python.
        [response format]:
        "reasoning": "Analysis of solving the coding question, including the algorithm needed, math equation need, core idea, and potential error to avoid, and etc."
        "python solution":
        ```python
        Python implementation of the function. Ensure the output of the function aligns with its specified return type.

        for example:
        [coding question]:
    def binary_search(arr, target):
        \"\"\"
        Perform binary search on a sorted array to find the index of a target value.

        Parameters:
        - arr (list): A sorted list of integers.
        - target (int): The value to be searched in the array.

        Returns:
        - int: The index of the target value in the array if found, or -1 if the target is not present.

        Example:
        >>> sorted_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        >>> target_value = 7
        >>> result = binary_search(sorted_array, target_value)
        >>> print(result)
        6  # Target 7 found at index 6 in the sorted array
        \"\"\"
        
        response:
        "reasoning": "The function employs binary search with two pointers, left and right, narrowing down the search range until the target is found or the range is empty.
    The math equation needed: The middle index is calculated using mid = left + (right - left) // 2, ensuring it remains within the current search range.
    The core idea: Binary search efficiently locates a target value in a sorted array by iteratively narrowing the search range, leveraging the array's sorted nature.
    The potential error to avoid: Input array (arr) must be sorted; additional checks needed for empty arrays. Guard against integer overflow during middle index calculation..",  
        "python solution":
        ```python
    def binary_search(arr, target):
        left, right = 0, len(arr) - 1

        while left <= right:
            mid = left + (right - left) // 2  # Calculate mid index to check the middle element

            if arr[mid] == target:
                return mid  # Target found, return the index
            elif arr[mid] < target:
                left = mid + 1  # If target is greater, narrow the search to the right half
            else:
                right = mid - 1  # If target is smaller, narrow the search to the left half

        return -1  # Target not found in the array
        ```
        Now solve this coding question: 
        {0}
        """.format(code_questions)
        result = LLM(prompt_final)
        try:
            result = extract_python_code(result)[0]
        except:
            result = '```python\n'+result + '```'
            result = extract_python_code(result)[0]
    imports = """from typing import List, Union, Tuple\nimport math\nfrom collections import Counter, deque\n"""
    result = imports + result
    try:
       with open('/data0/panguchain/pgpts/agents/all_logs/coder_4.txt', 'a') as f:
        f.write(result)
        f.write('\n======\n')
    except:
       pass
    return result

import re
def extract_python_code(text):
    pattern = r'```python\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches
#result = writecode_1('''"import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n", "entry_point": "find_zero", "canonical_solution": "    begin, end = -1., 1.\n    while poly(xs, begin) * poly(xs, end) > 0:\n        begin *= 2.0\n        end *= 2.0\n    while end - begin > 1e-10:\n        center = (begin + end) / 2.0\n        if poly(xs, center) * poly(xs, begin) > 0:\n            begin = center\n        else:\n            end = center\n    return begin\n"''')
#with open('/data0/panguchain/pgpts/agents/all_logs/coder_1.txt', 'a') as f:
#    f.write('===============================\n')
#    f.write(result)
#    f.write('===============================\n')

writecode_4=Tool(
        name="Coder_4",
        func=writecode_4,
        description=(
            "Coder_4(code_quesion:str) -> str:\n"
            " - Useful for when you need Coder_3 to write codes\n"
            " - Returns python solution.\n"
            " - `code_quesion`: a string representing a code quesion"
        ),
        stringify_rule=lambda args: f"Coder_4({args[0]})",
    )