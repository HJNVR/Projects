import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import sys
sys.path.append("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\LLM")
from UniAIGC import UniAIGC
LLM = UniAIGC()
#print(LLM("2+2"))
#exit()
from .base import Tool
#from src.agents.tools import Tool
import json
# "Large Scale Test Cases": "Third test case for function - **Objective**: To assess the function’s performance and scalability with large data samples. Do not include anything else."
# "Large Scale Test Cases" : "assert factorial(500)==1220136825991110068701238785423046926253574342803192842192413588385845373153881997605496447502203281863013616477148203584163378722078177200480785205159329285477907571939330603772960859086270429174547882424912726344305670173270769461062802310452644218878789465754777149863494367781037644274033827365397471386477878495438489595537537990423241061271326984327745715546309977202781014561081188373709531016356324432987029563896628911658974769572087926928871281780070265174507768410719624390394322536422605234945850129918571501248706961568141625359056693423813008856249246891564126775654481886506593847951775360894005745238940335798476363944905313062323749066445048824665075946735862074637925184200459369692981022263971952597190945217823331756934581508552332820762820023402626907898342451712006207714640979456116127629145951237229913340169552363850942885592018727433795173014586357570828355780158735432768888680120399882384702151467605445407663535984174430480128938313896881639487469658817504506926365338175055478128640000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, 'basic test cases'",
async def create_unit_tests(code_question):
    if "NOTESTCASE" in code_question:
        return ""
    systemprompt = '''
you are a helpful assistent generate test cases in specific format for given task .
some times there is several testcases the other time maybe only one testcase , some times the test cases in the code is only for format introducing other time the test cases contain correct values and can be used directly.
for the function need to complete , please first analysis the test case one by one , tell the user howmany examples the task offer , what is the input and out put , which of them can be use as a testcase? why? then write a test function .
your reply should be in such format:
# analysis
there are N examples in the task
## task 1 : ...
- input: ...
- output: ...
- analysis: ...
```python
# here is my analysis one by one :
# the ith case can be use 
analysis_i = "THE_DETAILED_ANALYSIS"
...
# the jth case is just for format introducing , because...
#based on the analysis , here is the test function :
print(f'{f()=}')
#if the function printed not as expected , raise the asserterror , use the analysis as the error message
assert testcasei , analysis_i
...
```'''
    userprompt = '''do you understand the task:
```python
{prompt}
```
please give me test function
'''
    prompt = '''import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
'''
    reply = '''
```python
# Here is my analysis one by one:
# The 1st case can be used
analysis_1 = "The function find_zero([1, 2]) should return -0.5 as it's the root of the equation f(x) = 1 + 2x , 1 + 2(-0.5) = 0"
# The 2nd case can be used
analysis_2 = "The function find_zero([-6, 11, -6, 1]) return 1.0 as it's one of the roots of the equation f(x) = -6 + 11x - 6x^2 + x^3 , f(x) = (x - 1) * (x - 2) * (x - 3) , if x=1,2or3,f(x)=0"

# Based on the analysis, here is the test function:
print(f'{{round(find_zero([1, 2]), 2)=}}')
assert round(find_zero([1, 2]), 2) == -0.5,analysis_1
print(f'{{find_zero([-6, 11, -6, 1]), 2)=}}')
assert round(find_zero([-6, 11, -6, 1]), 2) == 1.0,analysis_2
print('all passed')
```
'''
    userprompt = userprompt.format(prompt=prompt)
    prompt_final = systemprompt + '\n' + userprompt + '\n' + reply
    prompt_final += f"""\n Now help me generate test cases for this coding question: {code_question}"""
    #print(prompt_final)
    #exit()
    answer = LLM(prompt_final)
    print(answer)
    with open("/data0/panguchain/pgpts/agents/all_logs/unit_test.txt", 'a') as f:
        f.write(answer)
        f.write("======================================")
    try:
        answer = extract_python_code(answer)[0]
    except:
        return ""
    return answer

def create_unit_tests_35(prompt):
    system_prompt="""As a tester, your task is to create comprehensive test cases for the incomplete function. 
    These test cases should encompass Basic scenarios to ensure the code's robustness and reliability
    You MUST only respond in the format as described below. DO NOT RESPOND WITH ANYTHING ELSE. ADDING ANY OTHER EXTRA NOTES THAT VIOLATE THE RESPONSE FORMAT IS BANNED. START YOUR RESPONSE WITH ```python.
    [response format]: 
    ```python
    assert function(x) == xx, first test case"\nassert function(xx) == xxx, second test case for function"\n
    ```
    """
    sample_question = """def factorial(n):
        \"\"\"
        Returns the factorial of a positive integer n.
        >>> factorial(0)
        1
        >>> factorial(5)
        120
        \"\"\"
        """
    sample_response = """
    ```python
    assert factorial(4)==24, 'test case 1'\nassert factorial(0)==1, 'test case 2'\n
    ```
    """

    from openai import OpenAI
    client = OpenAI(api_key='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')
    completion = client.chat.completions.create(
    model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Help me generate unit test cases for this coding question: {sample_question}"},
        {"role": "assistant", "content": f"{sample_response}"},
        {"role": "user", "content": f"Help me generate unit test cases for this coding question: {prompt}"}
        #{"role": "user", "content": f"Here is the code: {code}, error: {error}, docstring: {docstring}. Please response with the codes in ```python block"}
    ]
    )
    result = completion.choices[0].message.content
    print(result)
    #test_cases = "\n".join(list(json.loads(result).values()))
    test_cases = extract_python_code(result)[0]
    with open('C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\logs\\test_cases.txt', 'a') as f:
        f.write(test_cases)
        f.write('\n======\n')
    return test_cases

'''
async def create_unit_tests(prompt):
    prompt_final = """
    As a tester, your task is to create comprehensive test cases for the incomplete function. 
    These test cases should encompass Basic and Edge scenarios to ensure the code's
    robustness, reliability, and scalability.
    [coding question]: {0}
    You MUST only respond in the format as described below. DO NOT RESPOND WITH ANYTHING ELSE. ADDING ANY OTHER EXTRA NOTES THAT VIOLATE THE RESPONSE FORMAT IS BANNED. START YOUR RESPONSE WITH '{{'.
    [response format]: 
    {{
      "Basic Test Cases": "First test case for function. - **Objective**: To verify the fundamental functionality. Do not include anything else.",
      "Edge Test Cases": "Second test case for function - **Objective**: To evaluate the function's behavior under extreme or unusual conditions. Do not include anything else.",
    }}

    for example:
    [coding question]:
    def factorial(n):
        \"\"\"
        Returns the factorial of a positive integer n.
        >>> factorial(0)
        1
        >>> factorial(5)
        120
        \"\"\"
    response:
    {{
        "Basic Test Cases" : "assert factorial(4)==24, 'basic test cases'",
        "Edge Test Cases" : "assert factorial(100)==93326215443944152681699238856266700490715968264381621468592963895217599993229915608941463976156518286253697920827223758251185210916864000000000000000000000000, 'Edge Test Cases'",
    }}
    PLEASE MAKE SURE YOUR RESPONSE IS IN JSON FORMAT.
    """.format(prompt)
    from openai import OpenAI
    client = OpenAI(api_key='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')
    completion = client.chat.completions.create(
    model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview",
    messages=[
        {"role": "system", "content": prompt_final},
        #{"role": "user", "content": f"Here is the code: {code}, error: {error}, docstring: {docstring}. Please response with the codes in ```python block"}
    ]
    )
    result = completion.choices[0].message.content
    test_cases = "\n".join(list(json.loads(result).values()))
    print(test_cases)
    return test_cases
    """
    count = 0
    #print('=')
    #print(json.loads(extract_python_code(LLM(prompt))[0])["assert lines"])
    #print('=')
    while True:
        count =+ 1
        if count == 2:
            break
        try:
            test_cases = extract_test_case(prompt)
            #print(test_cases)
            #print(json.loads(extract_python_code(test_cases)[0])["assert lines"])
            test_cases = "\n".join(json.loads(extract_python_code(test_cases)[0])["assert lines"])
            return test_cases
        except:
            continue
    return ""
    """
    """
    count = 0
    while True:
        count += 1
        if count == 2:
            return ""
        try:
            result = LLM(prompt_final + "\n YOU MUST RESPOND IN JSON FORMAT")
            test_cases = "\n".join(list(json.loads(result).values()))
            print(test_cases)
            return test_cases
        except:
            print("Generate Unit Test retry")
            continue
    """
    #print(test_cases)
    #exit()
    #return result
'''
import re
def extract_python_code(text):
    pattern = r'```python\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches

create_unit_tests=Tool(
        name="Tester",
        func=create_unit_tests_35,
        description=(
            "Tester(code_question:str) -> Dict:\n"
            " - Useful for when you need to generate unit tests\n"
            " - Returns unit test cases.\n"
            " - `prompt`: a string representing the coding signature and docstring"
        ),
        stringify_rule=lambda args: f"Tester({args[0]})",
    )
if __name__=='__main__':
    test_cases = create_unit_tests('''from typing import List\n\n\ndef has_close_elements(numbers: List[float], threshold: float) -> bool:\n    \"\"\" Check if in given list of numbers, are any two numbers closer to each other than\n    given threshold.\n    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)\n    False\n    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)\n    True\n    \"\"\"\n
                            ''')
    print(test_cases)