class ToolAgent():
    def __init__(
        self,
        name,
        role,
        profile,
        system_prompt,
        llm,
        toollist=[],
        watch=[],
        memory=[],
    ):
        self.name=name, 
        self.role=role,
        self.llm = llm
        self.toollist=toollist
        self.profile=profile
        self.system_prompt = system_prompt
        self.memory = [self.system_prompt]
    
    def run(self, query):
        tool = self.toollist[0]
        #print(tool.run(""))
    def percieve(self, message):
        self.memory.append(message)

    def show_memory(self):
        print(self.memory[1:])

