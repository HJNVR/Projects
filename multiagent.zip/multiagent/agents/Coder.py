import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import sys
sys.path.append("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\LLM")
from UniAIGC import UniAIGC
LLM = UniAIGC()
from .tool_agent import ToolAgent


from tools.write_code_tool_1 import writecode_1
from tools.write_code_tool_2 import writecode_2
from tools.write_code_tool_3 import writecode_3
from tools.write_code_tool_4 import writecode_4
from tools.write_code_tool_5 import writecode_5

# ==================================================================
name = "Coder_1"
role = "Code Developer"
profile = f"""{name}\n - Useful when you need Coder_1 to write codes\n"""
systemprompt = f"""Your name is {name} and you role is {role}\n. 
{profile}\n
Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
Years of experience: 3
Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas.
"""
tools = [writecode_1]
coder_1 = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)

name = "Coder_2"
role = "Code Developer"
profile = f"{name}\n - Useful when you need Coder_2 to write codes\n"
systemprompt = f"""Your name is {name} and you role is {role}. 
{profile}\n
Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
Years of experience: 3
Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas.
"""
tools = [writecode_2]
coder_2 = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)
name = "Coder_3"
role = "Code Developer"
profile = f"{name}\n - Useful when you need Coder_3 to write codes\n"
systemprompt = f"""Your name is {name} and you role is {role}. 
{profile}\n
Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
Years of experience: 3
Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas.
"""
tools = [writecode_3]
coder_3 = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)

name = "Coder_4"
role = "Code Developer"
profile = f"{name}\n - Useful when you need Coder_4 to write codes\n"
systemprompt = f"""Your name is {name} and you role is {role}. 
{profile}
Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
Years of experience: 3
Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas.
"""
tools = [writecode_4]
coder_4 = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)

name = "Coder_5"
role = "Code Developer"
profile = f"{name}\n - Useful when you need Coder_5 to write codes\n"
systemprompt = f"""Your name is {name} and you role is {role}. 
{profile}\n
Education background: Bachelor of Computer Science from National University of Singapore, Master of Artificial Intelligence from Carnegie Mellon University
    Years of experience: 3
    Coding awards: Winner of the ACM International Collegiate Programming Contest 2021, Runner-up of the Kaggle Machine Learning Challenge 2022, Finalist of the Google Code Jam 2023
    Personality: Curious, analytical, creative, and collaborative. Loves to learn new things and solve challenging problems. Enjoys working in a team and sharing ideas."""
tools = [writecode_5]
coder_5 = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)

# ==================================================================