import ast
import re
from typing import Any, Sequence, Union

import sys
from .task_fetching_unit import Task
from tools.base import StructuredTool, Tool

from langchain.agents.agent import AgentOutputParser
from langchain.schema import OutputParserException

THOUGHT_PATTERN = r"Thought: ([^\n]*)"
ACTION_PATTERN = r"\n*(\d+)\. (\w+)\((.*)\)(\s*#\w+\n)?"
# $1 or ${1} -> 1
ID_PATTERN = r"\$\{?(\d+)\}?"

END_OF_PLAN = "<END_OF_PLAN>"


def default_dependency_rule(idx, args: str):
    matches = re.findall(ID_PATTERN, args)
    numbers = [int(match) for match in matches]
    return idx in numbers


class LLMCompilerPlanParser(AgentOutputParser, extra="allow"):
    """Planning output parser."""

    #def __init__(self, tools: Sequence[Union[Tool, StructuredTool]], **kwargs):
    def __init__(self, agents, **kwargs):

        super().__init__(**kwargs)
        #self.tools = tools
        self.agents = agents

    def parse(self, text: str, current_q, coder_num) -> list[str]:
        #print(coder_num)
        #exit()
        # 1. search("Ronaldo number of kids") -> 1, "search", '"Ronaldo number of kids"'

        #print(text)
        #exit()
        #pattern = rf"(?:{THOUGHT_PATTERN}\n)?{ACTION_PATTERN}"
        #matches = re.findall(pattern, text)
        #print(matches)
        THOUGHT_PATTERN = r"Thought: ([^\n]*)"
        matches = re.findall(THOUGHT_PATTERN, text)
        #print(matches)
        #exit()
        try:
            thought_arg = matches[0]
        except:
            thought_arg = ""

        pattern = r"(\d+)\. (\w+)\(([^)]+)\)"
        matches = re.findall(pattern, text)
        matches = [match+('',) for match in matches]
        #print(matches)
        if coder_num == 5:
            matches=[('1', 'Coder_1', '', ''), ('2', 'Coder_2', '', ''), ('3', 'Coder_3', '', ''), ('4', 'Coder_4', '', ''), ('5', 'Coder_5', '', ''), ('6', 'Tester', '', ''), ('7', 'Experimenter', '$1+++$6', ''), ('8', 'Experimenter', '$2+++$6', ''), ('9', 'Experimenter', '$3+++$6', ''), ('10', 'Experimenter', '$4+++$6', ''), ('11', 'Experimenter', '$5+++$6', ''), ('12', 'DiscussionHoster', '$7+++$8+++$9+++$10+++$11', '')]
        elif coder_num == 3:
            matches=[('1', 'Coder_1', '', ''), ('2', 'Coder_2', '', ''), ('3', 'Coder_3', '', ''), ('4', 'Tester', '', ''), ('5', 'Experimenter', '$1+++$4', ''), ('6', 'Experimenter', '$2+++$4', ''), ('7', 'Experimenter', '$3+++$4', ''), ('8', 'DiscussionHoster', '$5+++$6+++$7', '')]
        elif coder_num == 1:
            matches = [('1', 'Coder_1', '', ''), ('2', 'Tester', '', ''), ('3', 'Experimenter', '$1+++$2', ''), ('4', 'DiscussionHoster', '$3', '')]
        matches.append((str(len(matches)+1), 'join', '', ''))
        graph_dict = {}
        #count = 1
        #all_agent_names = [agent.name[0] for agent in self.agents]
        #print(all_agent_names)
        #exit()
        #exist_name = []
        for match in matches:
            thought = ""
            idx, agent_name, args, _ = match
            idx = int(idx)
            if agent_name.startswith("Coder") or agent_name.startswith("Tester"):
                args = current_q
            #if agent_name.startswith("Experimenter"):
                #print(idx-coder_num-1)
            #    args = f"${idx-coder_num-1}+++${coder_num+1}"
            #elif agent_name.startswith("DiscussionHoster"):
            #    if coder_num == 5:
            #        args = f"$7+++$8+++$9+++$10+++$11"
            #    elif coder_num == 3:
            #        args = f"$5+++$6+++$7"
            #    elif coder_num == 1:
            #        args = f"$3"
            task = instantiate_task(
                #tools=self.tools,
                agents=self.agents,
                idx=idx,
                #tool_name=tool_name,
                agent_name=agent_name,
                args=args,
                thought=thought,
            )
            if agent_name == 'join':
                task.args=("<END_OF_PLAN>",)
                task.thought = (thought_arg,)
            graph_dict[idx] = task
            if task.is_join:
                break
        return graph_dict
### Helper functions


def _parse_llm_compiler_action_args(args: str) -> list[Any]:
    """Parse arguments from a string."""
    # This will convert the string into a python object
    # e.g. '"Ronaldo number of kids"' -> ("Ronaldo number of kids", )
    # '"I can answer the question now.", [3]' -> ("I can answer the question now.", [3])
    if args == "":
        return ()
    try:
        args = ast.literal_eval(args)
    except:
        args = args
    if not isinstance(args, list) and not isinstance(args, tuple):
        args = (args,)
    return args

def _find_agent(
        agent_name, agents
    ):
    for agent in agents:
        #print(agent.name, agent_name)
        #exit()
        if agent.name[0] == agent_name:
            return agent
    raise OutputParserException(f"Agent {agent_name} not found.")


def _find_tool(
    tool_name: str, tools: Sequence[Union[Tool, StructuredTool]]
) -> Union[Tool, StructuredTool]:
    """Find a tool by name.

    Args:
        tool_name: Name of the tool to find.

    Returns:
        Tool or StructuredTool.
    """
    #print("find_tool", tools)
    #print("find_tool", tool_name)
    for tool in tools:
        #print(tool.name, tool_name)
        if tool.name == tool_name:
            return tool
    raise OutputParserException(f"Tool {tool_name} not found.")


def _get_dependencies_from_graph(
    idx: int, tool_name: str, args: Sequence[Any]
) -> dict[str, list[str]]:
    """Get dependencies from a graph."""
    if tool_name == "join":
        # depends on the previous step
        dependencies = list(range(1, idx))
    else:
        # define dependencies based on the dependency rule in tool_definitions.py
        dependencies = [i for i in range(1, idx) if default_dependency_rule(i, args)]

    return dependencies


def instantiate_task(
    #tools: Sequence[Union[Tool, StructuredTool]],
    agents,
    idx: int,
    #tool_name: str,
    agent_name,
    args: str,
    thought: str,
) -> Task:
    dependencies = _get_dependencies_from_graph(idx, agent_name, args)
    #print("debug dependencies", dependencies)
    #exit()
    #dependencies = _get_dependencies_from_graph(idx, tool_name, args)
    args = _parse_llm_compiler_action_args(args)
    #print(args)
    #exit()
    #if tool_name == "join":
    if agent_name == "join":
        # join does not have a tool
        tool_func = lambda x: None
        stringify_rule = None
    else:
        #print("debug output_parser", agents[0].name)
        #exit()
        #tool = _find_tool(tool_name, agents)
        agent = _find_agent(agent_name, agents)
        #print("here", agent)
        #exit()
        tool = agent.toollist[0]
        tool_func = tool.func#tool._run#tool.func
        #print(tool_func)
        #exit()
        stringify_rule = tool.stringify_rule
    return Task(
        idx=idx,
        name=agent_name,#tool_name,
        tool=tool_func,
        args=args,
        dependencies=dependencies,
        stringify_rule=stringify_rule,
        thought=thought,
        is_join=agent_name == "join",##tool_name == "join",
    )
