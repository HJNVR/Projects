import fire
import sys
sys.path.append("../")
#from human_eval.data import HUMAN_EVAL
#from human_eval.evaluation import evaluate_functional_correctness
from data import HUMAN_EVAL
from evaluation import evaluate_functional_correctness

def entry_point(
    sample_file: str,
    k: str = "1,10,100",
    n_workers: int = 4,
    timeout: float = 3.0,
    problem_file: str = HUMAN_EVAL,
):
    """
    Evaluates the functional correctness of generated samples, and writes
    results to f"{sample_file}_results.jsonl.gz"
    """
    print(k.split(","))
    k = list(map(int, k.split(",")))
    print(k)
    results = evaluate_functional_correctness(sample_file, k, n_workers, timeout, problem_file)
    print(results)

#entry_point(sample_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_samples.jsonl",
#            problem_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_problem.jsonl")
def main():
    fire.Fire(entry_point)


sys.exit(main())

#entry_point(sample_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_samples.jsonl",
#            problem_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_problem.jsonl")
##print(entry_point(sample_file="samples_1.jsonl"))
#print(entry_point(sample_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_samples.jsonl"))
#def main():
#    fire.Fire(entry_point(sample_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_samples.jsonl",\
#            problem_file="/data0/panguchain/huangjing/benchmark/human-eval/data/example_problem.jsonl"))


#sys.exit(main())
