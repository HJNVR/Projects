import sys
sys.path.append("../")
from human_eval.data import write_jsonl, read_problems
sys.path.append("/data0/panguchain/pgpts/uniaigc")
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from uniaigc import generate
from UniAIGC import UniAIGC
LLM = UniAIGC()

problems = read_problems()
#print(problems["HumanEval/0"]["prompt"])
#print(problems[next(iter(problems))]) # dictionary
#N=10
#problems = dict(list(problems.items())[0: N]) 
#print(problems)
#import json
#with open('all_data.json', 'w') as f:
#    json.dump(problems, f)
#exit()
num_samples_per_task = 1
def generate_one_completion(prompt):
    temp = "Please pay more attention to the indentation. Make sure the generated code can run smoothly\n"
    return LLM(temp + prompt)
#for _ in range(num_samples_per_task):
#    for task_id in problems:
#ss        print(task_id)

#exit()
#with open("log.txt", 'a') as f:
#    f.write(problems["HumanEval/0"]["prompt"])
#print(generate_one_completion(problems["HumanEval/0"]["prompt"]))
#exit()
"""
samples = [
    dict(task_id=task_id, completion=generate_one_completion(problems[task_id]["prompt"]))
    for task_id in problems
    for _ in range(num_samples_per_task)
]
"""
text = open("/data0/panguchain/pgpts/agents/2024_1_7_result_uni_01_10times_1agent.txt", 'r')
content=text.read()
l = content.split('======')
print(len(l))
 
# returns JSON object as 
# a dictionary
#data = json.load(f)
#print(data)
#exit()
samples = [
    dict(task_id=task_id, completion=l[i]) 
    for i, task_id in enumerate(problems) if i < len(l)
]
#/data0/panguchain/pgpts/agents/2024_1_7_result_uni_01_10times.txt
write_jsonl(f"samples_{num_samples_per_task}_llmcompiler_2024_1_7_result_uni_01_10times.jsonl", samples)
exit()
samples = [
    dict(task_id=task_id, completion=generate_one_completion(problems[task_id]["prompt"]))
    for task_id in problems
    for _ in range(num_samples_per_task)
]
write_jsonl(f"samples_{num_samples_per_task}_indentation.jsonl", samples)

