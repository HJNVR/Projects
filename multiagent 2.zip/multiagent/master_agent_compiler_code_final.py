from langchain_community.chat_models import ChatOpenAI
from llm_compiler.llm_compiler import LLMCompiler
from src.utils.evaluation_utils import arun_and_time
from prompts.humaneval_prompt import planner_prompt_code_multi_1, output_prompt_code_multi_1, planner_prompt_code_multi_3, output_prompt_code_multi_3, planner_prompt_code_multi_5, output_prompt_code_multi_5
from agents.Coder import coder_1, coder_2, coder_3, coder_4, coder_5
from agents.Tester import tester
from agents.DiscussionHoster import discusshoster
from agents.Experimenter import experimenter
import pickle

END_OF_PLAN = "<END_OF_PLAN>"
JOINNER_FINISH = "Finish"
JOINNER_REPLAN = "Replan"

# ******************************************************
agents = [coder_1, coder_2, coder_3, coder_4, coder_5, tester, experimenter,discusshoster]
# ******************************************************

import argparse
argparser = argparse.ArgumentParser()
argparser.add_argument(
    "--benchmark_name",
    type=str,
    required=True,
    help="benchmark name",
    choices=["humaneval"],
)
argparser.add_argument("--coder_num", type=int, default=1, help="number of coders")
argparser.add_argument("--store", type=str, required=True, help="store path")
argparser.add_argument("--api_key", type=str, required=True, help="openai api key")
argparser.add_argument("--default_model", type=str, required=False, help="openai api type")
args = argparser.parse_args()

def get_dataset(args):
    import json
    if args.benchmark_name =="humaneval":
        f = open ("/Users/jinghuang/Desktop/multiagent/benchmark/humaneval_all_data.json", "r")
        data = json.loads(f.read())
    return data

def get_master_prompt(args):
    if args.benchmark_name =="humaneval":
        if args.coder_num == 1:return planner_prompt_code_multi_1, output_prompt_code_multi_1
        elif args.coder_num == 3:return planner_prompt_code_multi_3, output_prompt_code_multi_3
        elif args.coder_num == 5:return planner_prompt_code_multi_5, output_prompt_code_multi_5

def get_question_prompt(args):
    if args.benchmark_name =="humaneval":
        if args.coder_num == 1:return """Given the entry_point: {0}, I need Coder_1 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
        elif args.coder_num == 3:return """Given the entry_point: {0}, I need Coder_1, Coder_2, Coder_3 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
        elif args.coder_num == 5:return """Given the entry_point: {0}, I need Coder_1, Coder_2, Coder_3, Coder_4, Coder_5 to write codes of this coding question separately: {1}
        #and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together"""
CONFIGS = {
    "default_model": "gpt-3.5-turbo-1106",#"gpt-4-1106-preview",#"gpt-3.5-turbo-1106", #"uniaigc",#
    "data": {},
    "benchmark_name": '',
    "coder_num": 1,
    "planner_prompt": '',
    "output_prompt": '',
    "max_replans": 1,
    "question_prompt": '',
    "store": ''
}

CONFIGS['data'] = get_dataset(args)
CONFIGS['planner_prompt'], CONFIGS['output_prompt']= get_master_prompt(args)
CONFIGS['question_prompt'] = get_question_prompt(args)
CONFIGS["coder_num"] = args.coder_num
CONFIGS['benchmark_name'] = args.benchmark_name
CONFIGS['store'] = args.store
#print(type(CONFIGS))
#print(CONFIGS)
#exit()
with open("/Users/jinghuang/Desktop/multiagent/LLM/args.pkl", "wb") as f:
    pickle.dump(args, f)

#with open("/Users/jinghuang/Desktop/multiagent/LLM/config.json",'w') as f:
#    json.dump(CONFIGS, f)

# Actual Openai Model
planner_llm = ChatOpenAI(
            model_name=CONFIGS["default_model"],
            openai_api_key=args.api_key,
            temperature=0,
            streaming=False,
        )
llm = ChatOpenAI(
            model_name=CONFIGS["default_model"],
            openai_api_key=args.api_key,
            temperature=0,
            streaming=False,
        )


#print(CONFIGS)
#configs = CONFIGS#get_configs(args)
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_8_result_uni_10times_1agents.txt"
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_8_result_uni_10times_1agents.txt" --api_key='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'
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=3 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_8_result_uni_10times_3agents.txt" --api_key='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'
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=5 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_8_result_35_10times_5agents_final.txt" --api_key='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'
#exit()
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_8_result_uni_10times_1agents.txt" --api_key='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' --default_model="gpt-4-1106-preview"
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_18_result_gpt4_10times_1agents_failure.txt" --api_key='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' --default_model="gpt-4-1106-preview"
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_24_result_gpt4_10times_1agents_failure_testing.txt" --api_key='sk-promptappgpt-leogpt4' --default_model="gpt-4-1106-preview"
#python master_agent_compiler_code_final.py --benchmark_name="humaneval" --coder_num=1 --store="/Users/jinghuang/Desktop/multiagent/experiment_result_log/2024_1_24_result_gpt4_10times_1agents_failure_testing.txt" --api_key='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'
batch = 1
#import json
#f = open ("/data0/panguchain/huangjing/benchmark/human-eval/human_eval/all_data.json", "r")
#data = json.loads(f.read())
#print(len(data))

final_result = []
import asyncio
import time
async def main():
    start_time = time.time()
    # ['HumanEval/6', 'HumanEval/9', 'HumanEval/10', 'HumanEval/17', 'HumanEval/20', 'HumanEval/21', 'HumanEval/23', 'HumanEval/27']
    #len(CONFIGS['data'])
    # 0-99
    # len(CONFIGS['data'])
    #76 - is_simple_power timeout
    # [24,32,41,54,65,74,75,76,81,83,84,91,93,103,106,116,119,120,123,125,126,129,130,131,132,135,141,142,145,155,160,163]
    # 20, 32, 38, 41, 47, 64, 74, 75, 80
    # 20, 32, 38, 41, 46, 64, 74, 75, 80, 81, 91, 99, 100, 108, 116, 119, 120, 125, 128, 129, 130, 132, 134, 138, 140, 141, 145, 160, 163
    #[1, 10, 26, 28, 32, 59, 65, 75, 76, 83, 93, 99, 108, 116, 119, 120, 122, 130, 132, 134, 139, 141, 145, 163
    for i in [81]:#[116]:#range(100, len(CONFIGS['data']), batch):
    #for i in [108,110,112,116,119,122,125,126,127,129,130,131,132,134,135,137,140,145,151,153,154,163]:#range(105, len(CONFIGS['data']), batch):#163,len(CONFIGS['data']), batch):#[146,148,151,153,154,160,163]:#range(62,63,batch):
        octopus_agent = LLMCompiler(
        agents=agents,
        planner_llm=planner_llm,
        planner_example_prompt=CONFIGS['planner_prompt'],
        planner_example_prompt_replan=CONFIGS['planner_prompt'],
        planner_stop=[END_OF_PLAN],
        planner_stream=False,
        agent_llm=llm,
        joinner_prompt=CONFIGS['output_prompt'],
        joinner_prompt_final=None,
        max_replans=1,
        benchmark=False,
        batch=batch,
        total_data_len=len(CONFIGS['data']),
        current_q=CONFIGS['data'][f"HumanEval/{i}"]['prompt'],
        coder_num=CONFIGS['coder_num'],
        bench_mark_name=CONFIGS['benchmark_name'],
        store=CONFIGS['store']
        )
        
        question = ' '.join([CONFIGS['question_prompt'].format(CONFIGS['data'][key]['entry_point'], CONFIGS['data'][key]['prompt']) for key in dict(list(CONFIGS['data'].items())[i:i+batch]).keys()])
        async def one_iteration(question):
            result = await arun_and_time(octopus_agent.arun, question)
            return result
        result = await one_iteration(question)
        final_result.append(result)
        time.sleep(0)
    print("--- %s seconds ---" % (time.time() - start_time))
    return final_result

results = asyncio.get_event_loop().run_until_complete(main())
#print(results)
