from openai import OpenAI
client = OpenAI(api_key='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')
completion = client.chat.completions.create(
model="gpt-3.5-turbo",#"gpt-4-1106-preview",
messages=[
    {"role": "system", "content": "Tell me a joke"
    }
]
)
result = completion.choices[0].message.content
print(result)