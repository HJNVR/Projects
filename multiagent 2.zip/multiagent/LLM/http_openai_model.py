import pickle
import requests
import os
import time
# Read the arguments from the pickle file
with open("/Users/jinghuang/Desktop/multiagent/LLM/args.pkl", "rb") as f:
    CONFIGS = pickle.load(f)

class HttpOpenAIModel:
     def __init__(self):
          self.config = CONFIGS
     def __call__(self, messages):
        # Replace 'your_openai_api_key' with your actual OpenAI API key
        openai_api_key = self.config.api_key#'sk-promptappgpt-leogpt4'

        # Set the URL for the API endpoint
        url = 'https://openai-pag.wangzhishi.net/v1/chat/completions'

        # Set the headers
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer sk-promptappgpt-leogpt4'
        }

        # Define the payload (data) for the POST request
        data = {
            'model': 'gpt-4-1106-preview',
            'messages': messages
        }

        for _ in range(10):
            # Make the POST request
            response = requests.post(url, json=data, headers=headers,verify=False)
            if response.status_code == 200:
                break
            print("Start to wait becasuse of response error")
            time.sleep(3) 
        response = response.json()['choices'][0]['message']['content'] # token usage
        return response
         