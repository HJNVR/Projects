from openai import OpenAI
import pickle
# Read the arguments from the pickle file
with open("/Users/jinghuang/Desktop/multiagent/LLM/args.pkl", "rb") as f:
    CONFIGS = pickle.load(f)
class OpenAIModel:
     def __init__(self):
          self.config = CONFIGS
     def __call__(self, messages):
         client = OpenAI(api_key=self.config.api_key)
         completion = client.chat.completions.create(
            model=self.config.default_model,
            messages=messages
            )
         result = completion.choices[0].message.content
         return result
         