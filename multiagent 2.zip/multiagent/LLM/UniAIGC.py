import time 
import json
from typing import Any, List, Mapping, Optional
import requests
from requests import ReadTimeout
import sys
sys.path.append("/data0/huangjing/workspace/datacom_ui/demo/langchain/libs/langchain")
from langchain.llms.base import LLM

class UniAIGC(LLM): 
    #n: int
    iam_api_url = 'https://iam.his-op-beta.huawei.com/iam/auth/token'
    llm_api_url = 'https://chatbot.his-beta.huawei.com/aigc-api-gateway/aigc-model-gateway/dialogue'
    """
    header = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
    'Content-Type': 'application/json',
    }
    """
    header = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
    'Content-Type': 'application/json',
    }

    """
    def get_iam_token(self):
        body = {
            "data":
                {"type": "token", "attributes":
                    {
                        "account": "com.huawei.sg.poisson",
                        "secret": "ZlHurfKDUwlLbOniqX0cTWPyOy5Qnk2Wvf7n5NQN",
                        "project": "com.huawei.sg.poisson",
                        "enterprise": "11111111111111111111111111111111"
                    }
                }
        }
        req = requests.post(self.iam_api_url, json=body, headers=self.header, verify=False, timeout=60)
        return json.loads(req.text)['access_token']
    """

    # get token
    def get_iam_token(self):
        body = {
            "data":
                {"type": "token", "attributes":
                    {
                        "account": "com.huawei.sg.poisson",
                        "secret": "yzfzWKhO5a/iCC+tDLElh0u4aQ3LpBH5Pd3mYlML",
                        "project": "com.huawei.sg.poisson",
                        "enterprise": "11111111111111111111111111111111"
                    }
                }
        }
        req = requests.post(self.iam_api_url, json=body, headers=self.header, verify=False, timeout=60)
        #print(json.loads(req.text))
        return json.loads(req.text)['access_token']

    def get_validate_input(self):
        while (1):
            org_input = input()
            input_s = org_input.strip()
            if input_s == "":
                print("input can't be NULL")
            else:
                return input_s
        
    def generate_text(self, question):
        iam_token = self.get_iam_token()
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
            'Content-Type': 'application/json',
            'Authorization': iam_token,
        }
        # header['Authorization'] = iam_token

        """
        body = {
            "question": question,
            "userId": "g00823392",
            "taskUuid": "bb87e838-e5d7-4aad-be29-ead7a0c83ef1"
        }
        """
        body = {
        "question": question,
        "userId": "g00823392",
        "taskUuid": "e2ad54a1-85ed-4a08-aa14-4205c578f915"
        }
        count = 0
        while (1):
            try:
                req = requests.post(self.llm_api_url, json=body, headers=headers, timeout=120, verify=False) #<Response [200]>
                if req.text:
                    return json.loads(req.text) # ['choices'][0]['content']
                else:
                    count += 1
                    print(f"Reattempt {count}")
                    time.sleep(2)
            except (TimeoutError, ReadTimeout) as e:
                print(f"request AIGC port timeout.")
                raise e
            except Exception as e:
                print(f"Meet other errors when sending the request.")
                raise e

    @property
    def _llm_type(self) -> str:
        return "custom"
    #run_manager: Optional[CallbackManagerForLLMRun] = None,
    async def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> str:
        response = self.generate_text(prompt)['choices'][0]['content']
        #with open("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\logs\\llm_log.txt", 'a') as log_file:
        #    log_file.write("="*20+'\n')
        #    log_file.write(response+'\n')
        #    log_file.write("="*20+'\n')
        return response
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> str:
        response = self.generate_text(prompt)['choices'][0]['content']
        #with open("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\logs\\llm_log.txt", 'a') as log_file:
        #    log_file.write("="*20+'\n')
        #    log_file.write(response+'\n')
        #    log_file.write("="*20+'\n')
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        #return {"n": self.n}
        return {"iam_api_url": self.iam_api_url, "llm_api_url": self.llm_api_url}

if __name__ == "__main__":
    # test
    LLM = UniAIGC()
    print(LLM("Calculate 1 + 1"))