planner_prompt_code_multi_1=(
    'Question: Given the entry_point: `sum_of_integers`, I need Coder_1 write codes of this coding question separately: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '2. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '3. Experimenter($1+++$2)\n'
    '4. DiscussionHoster($3)\n'
    "Thought: I can answer the question now.\n"
    '5. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
    'Question: Given the entry_point: `find_zero`, I need Coder_1 to write codes of this coding question separately: import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '2. Tester(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '3. Experimenter($1+++$2)\n'
    '4. DiscussionHoster($3)\n'
    "Thought: I can answer the question now.\n"
    '5. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
)


output_prompt_code_multi_1 = (
    "Solve a question answering task with interleaving Observation, Thought, and Action steps. Here are some guidelines:\n"
    "  - You will be given a Question and some Wikipedia passages, which are the Observations.\n"
    "  - Thought needs to reason about the question based on the Observations in 1-2 sentences.\n"
    "  - There are cases where the Observations are unclear or irrelevant (in the case wikipedia search was not successful). In such a case where the Observations are unclear, you must make a best guess based on your own knowledge if you don't know the answer. You MUST NEVER say in your thought that you don't know the answer.\n\n"
    "Action can be only one type:\n"
    f" (1) Finish(answer): returns the answer and finishes the task. "
    "Answer should be short and a single item and MUST not be multiple choices. Answer MUST NEVER be 'unclear', 'unknown', 'neither', 'unrelated' or 'undetermined', and otherwise you will be PENALIZED.\n"
    "\n"
    "Here are some examples:\n"
    "\n"
    'Question: Given the entry_point: `sum_of_integers`,  I need Coder_1 to write codes of this coding question: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    "\n"
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b'
    '2. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    "Observation: assert sum_of_integers(1,2) == 3"
    '3. Experimenter($1+++$2)\n'
    "Observatiion: pass"
    '4. DissusionHoster($3)\n'
    'Observatiion: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)'
    "Thought: I have generated codes and unit tests for the coding questions, then after the exection of the codes with the unit tests, there is no error messages"
    f"Action: Finish()\n"
    "###\n"
    "\n"
)

planner_prompt_code_multi_3=(
    'Question: Given the entry_point: `sum_of_integers`, I need Coder_1, Coder_2 and Coder_3 to write codes of this coding question separately: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '2. Coder_2(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '3. Coder_3(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '4. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '5. Experimenter($1+++$4)\n'
    '6. Experimenter($2+++$4)\n'
    '7. Experimenter($3+++$4)\n'
    '8. DiscussionHoster($5+++$6+++$7)\n'
    "Thought: I can answer the question now.\n"
    '9. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
    'Question: Given the entry_point: `find_zero`, I need Coder_1, Coder_2 and Coder_3 to write codes of this coding question separately: import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '2. Coder_2(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '3. Coder_3(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '4. Tester(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '5. Experimenter($1+++$4)\n'
    '6. Experimenter($2+++$4)\n'
    '7. Experimenter($3+++$4)\n'
    '8. DiscussionHoster($5+++$6+++$7)\n'
    "Thought: I can answer the question now.\n"
    '9. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
)

output_prompt_code_multi_3 = (
    "Solve a question answering task with interleaving Observation, Thought, and Action steps. Here are some guidelines:\n"
    "  - You will be given a Question and some Wikipedia passages, which are the Observations.\n"
    "  - Thought needs to reason about the question based on the Observations in 1-2 sentences.\n"
    "  - There are cases where the Observations are unclear or irrelevant (in the case wikipedia search was not successful). In such a case where the Observations are unclear, you must make a best guess based on your own knowledge if you don't know the answer. You MUST NEVER say in your thought that you don't know the answer.\n\n"
    "Action can be only one type:\n"
    f" (1) Finish(answer): returns the answer and finishes the task. "
    "Answer should be short and a single item and MUST not be multiple choices. Answer MUST NEVER be 'unclear', 'unknown', 'neither', 'unrelated' or 'undetermined', and otherwise you will be PENALIZED.\n"
    "\n"
    "Here are some examples:\n"
    "\n"
    'Question: Given the entry_point: `sum_of_integers`,  I need Coder_1, Coder_2 and Coder_3 to write codes of this coding question: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    "\n"
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b'
    '2. Coder_2(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """ )\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)'
    '3. Coder_3(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum([a, b])'
    '4. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    "Observation: assert sum_of_integers(1,2) == 3"
    '5. Experimenter($1+++$4)\n'
    "Observatiion: pass"
    '6. Experimenter($2+++$4)\n'
    "Observatiion: pass"
    '7. Experimenter($3+++$4)\n'
    "Observatiion: pass"
    '8. DissusionHoster($5+++$6+++$7)\n'
    'Observatiion: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)'
    "Thought: I have generated codes and unit tests for the coding questions, then after the exection of the codes with the unit tests, there is no error messages"
    f"Action: Finish()\n"
    "###\n"
    "\n"
)

planner_prompt_code_multi_5=(
    'Question: Given the entry_point: `sum_of_integers`, I need Coder_1, Coder_2, Coder_3, Coder_4, Coder_5 to write codes of this coding question separately: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '2. Coder_2(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '3. Coder_3(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '4. Coder_4(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '5. Coder_5(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '6. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    '7. Experimenter($1+++$6)\n'
    '8. Experimenter($2+++$6)\n'
    '9. Experimenter($3+++$6)\n'
    '10. Experimenter($4+++$6)\n'
    '11. Experimenter($5+++$6)\n'
    '12. DiscussionHoster($7+++$8+++$9+++$10+++$11)\n'
    "Thought: I can answer the question now.\n"
    '13. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
    'Question: Given the entry_point: `find_zero`, I need Coder_1, Coder_2, Coder_3, Coder_4, Coder_5 to write codes of this coding question separately: import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    '1. Coder_1(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '2. Coder_2(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '3. Coder_3(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '4. Coder_4(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '5. Coder_5(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '6. Tester(import math\n\n\ndef poly(xs: list, x: float):\n    \"\"\"\n    Evaluates polynomial with coefficients xs at point x.\n    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n\n    \"\"\"\n    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])\n\n\ndef find_zero(xs: list):\n    \"\"\" xs are coefficients of a polynomial.\n    find_zero find x such that poly(x) = 0.\n    find_zero returns only only zero point, even if there are many.\n    Moreover, find_zero only takes list xs having even number of coefficients\n    and largest non zero coefficient as it guarantees\n    a solution.\n    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x\n    -0.5\n    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3\n    1.0\n    \"\"\"\n'
    '7. Experimenter($1+++$6)\n'
    '8. Experimenter($2+++$6)\n'
    '9. Experimenter($3+++$6)\n'
    '10. Experimenter($4+++$6)\n'
    '11. Experimenter($5+++$6)\n'
    '12. DiscussionHoster($7+++$8+++$9+++$10+++$11)\n'
    "Thought: I can answer the question now.\n"
    '13. join()<END_OF_PLAN>\n'
    "###\n"
    "\n"
)

output_prompt_code_multi_5 = (
    "Solve a question answering task with interleaving Observation, Thought, and Action steps. Here are some guidelines:\n"
    "  - You will be given a Question and some Wikipedia passages, which are the Observations.\n"
    "  - Thought needs to reason about the question based on the Observations in 1-2 sentences.\n"
    "  - There are cases where the Observations are unclear or irrelevant (in the case wikipedia search was not successful). In such a case where the Observations are unclear, you must make a best guess based on your own knowledge if you don't know the answer. You MUST NEVER say in your thought that you don't know the answer.\n\n"
    "Action can be only one type:\n"
    f" (1) Finish(answer): returns the answer and finishes the task. "
    "Answer should be short and a single item and MUST not be multiple choices. Answer MUST NEVER be 'unclear', 'unknown', 'neither', 'unrelated' or 'undetermined', and otherwise you will be PENALIZED.\n"
    "\n"
    "Here are some examples:\n"
    "\n"
    'Question: Given the entry_point: `sum_of_integers`, I need Coder_1, Coder_2, Coder_3, Coder_4, Coder_5 to write codes of this coding question separately: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\
    and create unit tests for this coding question, then expereiment the codes together with the unit tests separately, finally discuss the codes together'
    "\n"
    '1. Coder_1(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b'
    '2. Coder_2(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """ )\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)'
    '3. Coder_3(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum([a, b])'
    '4. Coder_4(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(x for x in [a, b])'
    '5. Coder_5(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """)\n'
    'Observation: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return reduce(lambda x, y: x + y, [a, b])'
    '6. Tester(def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """'
    "Observation: assert sum_of_integers(1,2) == 3"
    '7. Experimenter($1+++$6)\n'
    "Observatiion: pass"
    '8. Experimenter($2+++$6)\n'
    "Observatiion: pass"
    '9. Experimenter($3+++$6)\n'
    "Observatiion: pass"
    '10. Experimenter($4+++$6)\n'
    "Observatiion: pass"
    '11. Experimenter($5+++$6)\n'
    "Observatiion: pass"
    '12. DiscussionHoster($7+++$8+++$9+++$10+++$11)\n'
    'Observatiion: def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)'
    "Thought: I have generated codes and unit tests for the coding questions, then after the exection of the codes with the unit tests, there is no error messages"
    f"Action: Finish()\n"
    "###\n"
    "\n"
)
