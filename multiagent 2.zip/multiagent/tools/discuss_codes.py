from .base import Tool
from .write_code_tool_1 import CURRENT_CODE_QUESTION
import sys
sys.path.append("/Users/jinghuang/Desktop/multiagent/LLM")
from openai_model import OpenAIModel
from http_openai_model import HttpOpenAIModel
#LLM = OpenAIModel()
LLM = HttpOpenAIModel()
async def discuss_35(codes):
    print("Discuss Hoster working")
    codes_l = codes.split('+++')
    print("!!!!!!!!")
    print(codes_l)
    print("!!!!!!!!")
    CURRENT_CODE_QUESTION = codes_l[0].split('+sep+')[-1]
    #print("0000000000")
    #print(CURRENT_CODE_QUESTION )
    #print("0000000000")
    correct_code = [code for code in codes_l if 'traceback' not in code.lower()]
    if not correct_code:
        print("no correct answer")
        return "REFLEXION"
    correct_code = [code.split('+sep+')[1] for code in codes_l]
    system_prompt = """You are professional python code developer, you should review a list of codes and choose the best one given the coding quesion. You must provide both `reasoning` and `python_solution`"""
    sample_codes = '''['def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b',
    'def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)']'''
    sample_question = '''def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n'''
    sample_response = '''"reasoning": "Both python codes are correct, but the first one is more clean"
    "python solution":
    ```python
    def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b
    ```
    '''
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Given the coding quesion: {sample_question}, help me choose the best code from this list of codes: {sample_codes}"},
        {"role": "assistant", "content": f"{sample_response}"},
        {"role": "user", "content": f"Given the coding quesion: {CURRENT_CODE_QUESTION}, help me choose the best code from this list of codes: {codes}. Please response with the codes in ```python block. You must pay more attention to the indentation. Make sure the code is runnable by Python."}
        #{"role": "user", "content": f"Here is the code: {code}, error: {error}, docstring: {docstring}. Please response with the codes in ```python block"}
    ]
    #print(CURRENT_CODE_QUESTION)
    #exit()
    answer = LLM(messages)
    #print(answer)
    answer = extract_python_code(answer)[0]
    with open('/Users/jinghuang/Desktop/multiagent/logs/answer.txt', 'a') as f:
        f.write(answer)
        f.write('\n======\n')
    return answer


async def discuss(codes):
    codes_l = codes.split('+++')
    print("!!!!!!!!")
    print(codes_l)
    print("!!!!!!!!")
    correct_code = [code for code in codes_l if 'traceback' not in code.lower()]
    if not correct_code:
        print("no correct answer")
        return "REFLEXION"
    correct_code = [code.split('+sep+')[1] for code in codes_l]
    system_prompt = """You are professional python code developer, you should review a list of codes and choose the best one given the coding quesion"""
    sample_codes = '''['def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b',
    'def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return sum(a, b)']'''
    sample_question = '''def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n'''
    sample_response = '''"reasoning": "Both python codes are correct, but the first one is more clean"
    "python solution":
    ```python
    def sum_of_integers(a: int, b: int) -> int:\n    """\n    Return the sum of two integers\n    >>> sum_of_integer(0,0)\n    0\n    """\n    return a + b
    ```
    '''
    prompt_final = system_prompt + '\n' + sample_codes + '\n' + sample_question + '\n' + sample_response
    prompt_final += f"\n Now Hlep me reviwe this codes: {correct_code} and respond the best code. Please start you response for python solution with ```python\
        YOU MUST KEPP CLEAN INDENATION AND INCLUDE NECESSARY IMPORT. for example: `import math`, `from typing import List`, and etc."
    answer = LLM(prompt_final)
    try:
        answer = extract_python_code(answer)[0]
    except:
        answer = '```python\n'+answer + '```'
        answer = extract_python_code(answer)[0]
    with open('/data0/panguchain/pgpts/agents/all_logs/discussion.txt', 'a') as f:
        f.write(answer)
        f.write('============================')
    return answer







def correct_indent(codes):
    system_prompt = "You are a professional code developer. You will receive a code snippet as an input. You should check the code indentation and fix any errors or inconsistencies. If the code indentation has no issue, you should reply with the original code.\n\
                    START YOUR RESPONSE WITH ```python"
    sample_question = "def sum_of_integer(a,b):\nreturn a + b"
    sample_response = "```python\ndef sum_of_integer(a,b):\n    return a + b\n```"
    from openai import OpenAI
    client = OpenAI(api_key='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')
    while True:
        completion = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",#"gpt-4-1106-preview",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Help me check the indendation of this codes: {sample_question}"},
            {"role": "assistant", "content": f"{sample_response}"},
            {"role": "user", "content": f"Help me check the indendation of this codes: {codes}"},
        ]
        )
        codes = completion.choices[0].message.content
        print("correct_indenation", codes)
        try:
            result = extract_python_code(codes)[0]
            return result
        except:
            continue

#def reflexion("")

import re
def extract_python_code(text):
    pattern = r'```python\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches

discuss=Tool(
        name="DiscussionHoster",
        func=discuss_35,
        description=(
            "DiscussionHoster(codes:str) -> str:\n"
            " - Useful for when you need to discuss codes\n"
            " - Returns python solution.\n"
            " - `codes`: a string representing codes"
        ),
        stringify_rule=lambda args: f"DiscussionHoster({args[0]})",
    )