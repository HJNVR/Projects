from .base import Tool
import json
import sys
sys.path.append("/Users/jinghuang/Desktop/multiagent/LLM")
from openai_model import OpenAIModel
from http_openai_model import HttpOpenAIModel
#LLM = OpenAIModel()
LLM = HttpOpenAIModel()
async def create_unit_tests_35(prompt):
    if "NOTESTCASE" in prompt:
        return ""
    elif "+sep+" in prompt:
        code_questions_l = prompt.split('+exp_sep+')
        variables = []

        for code_question in code_questions_l[:-1]:
            temp = code_question.split("+sep+")
            variables.append(temp)
        system_prompt = '''you are a helpful assistent generate test cases in specific format for given task .
            You will learn from previous attempts, including `previous_error` , `previous_python_solution`, `previous_standardout`, `previous_testcases` and `previous_analysis`
            Then gather all the insights from these attemps and generate better testcases for a given coding question. 

            some times there is several testcases the other time maybe only one testcase , some times the test cases in the code is only for format introducing other time the test cases contain correct values and can be used directly.
            for the function need to complete , please first analysis the test case one by one , tell the user howmany examples the task offer , what is the input and out put , which of them can be use as a testcase? why? then write a test function .
            your reply should be in such format:
            # reply
            here is the code you can directly paste to the draft , used as a test
            ```python
            # there is N cases in total Here is my analysis one by one:
            # The 1st case can not(or can) be used
            analysis_1 = """
            the input is : ...
            the out put is : ...
            my analysis of this case : the analysis should be really detailed .
            ...
            # Based on the analysis, here is the test functions(only contain the testcase can be used):
            print(f'{{LEFT_SIDE_OF_TESTLINE_1=}}')
            assert LEFT_SIDE_OF_TESTLINE_1==RIGHT_SIDE_OF_TESTLINE_1,analysis_1
            ...
            print('all passed')
            ``` 
            '''
        if len(variables) == 5:
            # access the variables by indexing the variables list
            CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
            _, prev_error_2, prev_codes_2, prev_out_2, prev_testcases_2, prev_analysis_2 = variables[1][0], variables[1][1], variables[1][2], variables[1][3], variables[1][4], variables[1][5]
            _, prev_error_3, prev_codes_3, prev_out_3, prev_testcases_3, prev_analysis_3 = variables[2][0], variables[2][1], variables[2][2], variables[2][3], variables[2][4],  variables[2][5]
            _, prev_error_4, prev_codes_4, prev_out_4, prev_testcases_4, prev_analysis_4 = variables[3][0], variables[3][1], variables[3][2], variables[3][3], variables[3][4], variables[3][5]
            _, prev_error_5, prev_codes_5, prev_out_5, prev_testcases_5, prev_analysis_5 = variables[4][0], variables[4][1], variables[4][2], variables[4][3], variables[4][4],  variables[4][5]
            user_prompt = """Now please learn from all these attemtps:
        Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
        Attempt 2. previous error: {error_2}, previous_python_solution: {codes_2}, `previous_standardout`: {out_2}, `previous_testcases`: {testcase_2}, `previous_analysis`: {analysis_2}
        Attempt 3. previous error: {error_3}, previous_python_solution: {codes_3}, `previous_standardout`: {out_3}, `previous_testcases`: {testcase_3}, `previous_analysis`: {analysis_3}
        Attempt 4. previous error: {error_4}, previous_python_solution: {codes_4}, `previous_standardout`: {out_4}, `previous_testcases`: {testcase_4}, `previous_analysis`: {analysis_4}
        Attempt 5. previous error: {error_5}, previous_python_solution: {codes_5}, `previous_standardout`: {out_5}, `previous_testcases`: {testcase_5}, `previous_analysis`: {analysis_5}
        then generate better testcases for this question: {code_question}
        """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
                    error_2=prev_error_2, codes_2=prev_codes_2, out_2 = prev_out_2, testcase_2=prev_testcases_2, analysis_2=prev_analysis_2,
                    error_3=prev_error_3, codes_3=prev_codes_3, out_3 = prev_out_3, testcase_3=prev_testcases_3, analysis_3=prev_analysis_3,
                    error_4=prev_error_4, codes_4=prev_codes_4, out_4 = prev_out_4, testcase_4=prev_testcases_4, analysis_4=prev_analysis_4,
                    error_5=prev_error_5, codes_5=prev_codes_5, out_5 = prev_out_5, testcase_5=prev_testcases_5, analysis_5=prev_analysis_5,
            code_question=CURRENT_CODE_QUESTION)
        elif len(variables) == 3:
            # access the variables by indexing the variables list
            CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]
            _, prev_error_2, prev_codes_2, prev_out_2, prev_testcases_2, prev_analysis_2 = variables[1][0], variables[1][1], variables[1][2], variables[1][3], variables[1][4], variables[1][5]
            _, prev_error_3, prev_codes_3, prev_out_3, prev_testcases_3, prev_analysis_3 = variables[2][0], variables[2][1], variables[2][2], variables[2][3], variables[2][4],  variables[2][5]
            user_prompt ="""Now please learn from all these attemtps:
        Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
        Attempt 2. previous error: {error_2}, previous_python_solution: {codes_2}, `previous_standardout`: {out_2}, `previous_testcases`: {testcase_2}, `previous_analysis`: {analysis_2}
        Attempt 3. previous error: {error_3}, previous_python_solution: {codes_3}, `previous_standardout`: {out_3}, `previous_testcases`: {testcase_3}, `previous_analysis`: {analysis_3}
        then generate better testcases for this question: {code_question}
        """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
                    error_2=prev_error_2, codes_2=prev_codes_2, out_2 = prev_out_2, testcase_2=prev_testcases_2, analysis_2=prev_analysis_2,
                    error_3=prev_error_3, codes_3=prev_codes_3, out_3 = prev_out_3, testcase_3=prev_testcases_3, analysis_3=prev_analysis_3,
            code_question=CURRENT_CODE_QUESTION)
        elif len(variables) == 1:
            # access the variables by indexing the variables list
            CURRENT_CODE_QUESTION, prev_error_1, prev_codes_1, prev_out_1, prev_testcases_1, prev_analysis_1  = variables[0][0], variables[0][1], variables[0][2], variables[0][3], variables[0][4], variables[0][5]

            user_prompt="""Now please learn from all these attemtps:
        Attempt 1. previous error: {error_1}, previous_python_solution: {codes_1}, `previous_standardout`: {out_1}, `previous_testcases`: {testcase_1}, `previous_analysis`: {analysis_1}
        then generate better testcases for this question: {code_question} 
        """.format(error_1=prev_error_1, codes_1=prev_codes_1, out_1 = prev_out_1, testcase_1=prev_testcases_1, analysis_1=prev_analysis_1,
                    code_question=CURRENT_CODE_QUESTION)
            
        with open('/Users/jinghuang/Desktop/multiagent/logs/test_cases_reflexion_prompt.txt', 'a') as f:
            f.write(user_prompt)
            f.write('\n======\n')

        while True:
            try:
                m1 = {'role':'system','content':system_prompt}
                rootmessages = [m1]
                messages = rootmessages
                messages.append({
                    "role":"user",
                    "content":user_prompt
                })
                result = LLM(messages)
                print("test", result)
                test_cases = extract_python_code(result)[0]
                #exit()
                #test_cases = parse_json_block(result)
                #test_cases = "\n".join(test_cases["assert lines"])
                with open('/Users/jinghuang/Desktop/multiagent/logs/test_cases_reflexion.txt', 'a') as f:
                    f.write(test_cases)
                    f.write('\n======\n')
                return test_cases
            except:
                import time
                time.sleep(1)
                continue
        #print("\n".join(test_cases["assert lines"]))
        #exit()    
    else:
    #     systemprompt='''you are a helpful assistent generate test cases in specific format for given task .
    # you will receive some code complete task in such format:
    # ```python
    # import ...(the packages)
    # #some functions predefined herec
    # def PREDEFINED_FUNCTION_NAME():
    #     """THE_FUNCTION_REFERENCE"""
    #     #some code
    # ...
    # #the up ward function is completed you don't need complete , the next is to complete
    # def THE_FUNCTION_NAME():
    #     """THE_FUNCTION_REFERENCE"""
    #     #TODO
    # ```
    # but you won't do this part of work , user will do this part later , you only need give back test cases for user to check him self.
    # you simply give back testcases in such json format:
    # {{
    #     "testcases":int
    #     "assert lines":[
    #         "assert f(input)==output,'testcases 1'",
    #         ...
    #     ]
    # }}
    # '''
    #     usertemplete = '''please give me the test cases , here is the original task
    # ```python
    # {demo_code}
    # ```
    # '''
    #     assistenettemplete = '''
    # sure , here is my reply :
    # ```python
    # {demo_json}
    # ```
    # '''
    #     demo_json = """
    # {"testcases":2,"assert lines":["assert has_close_elements([1.0, 2.0, 3.0], 0.5)==False,'test case 1'","assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)==True,'test case 2'"]}
    # """
    #     demo_code = '''
    # from typing import List
    # def has_close_elements(numbers: List[float], threshold: float) -> bool:
    #     """ Check if in given list of numbers, are any two numbers closer to each other than
    #     given threshold.
    #     >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    #     False
    #     >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    #     True
    #     """
    # '''
        systemprompt = '''
    you are a helpful assistent generate test cases in specific format for given task .
    some times there is several testcases the other time maybe only one testcase , some times the test cases in the code is only for format introducing other time the test cases contain correct values and can be used directly.
    for the function need to complete , please first analysis the test case one by one , tell the user howmany examples the task offer , what is the input and out put , which of them can be use as a testcase? why? then write a test function .
    your reply should be in such format:
    # reply
    here is the code you can directly paste to the draft , used as a test
    ```python
    # there is N cases in total Here is my analysis one by one:
    # The 1st case can not(or can) be used
    analysis_1 = """
    the input is : ...
    the out put is : ...
    my analysis of this case : the analysis should be really detailed .
    ...
    # Based on the analysis, here is the test functions(only contain the testcase can be used):
    print(f'{{LEFT_SIDE_OF_TESTLINE_1=}}')
    assert LEFT_SIDE_OF_TESTLINE_1==RIGHT_SIDE_OF_TESTLINE_1,analysis_1
    ...
    print('all passed')
    ```'''
        user_prompt = '''do you understand the task:
                    ```python
                    {prompt}
                    ```
                    please give me test function taht i can paste directly under my code , don't implement the code
                    '''.format(prompt=prompt)
    while True:
        try:
            #m1 = {"role":"system","content":systemprompt}
            #m2 = {"role":"user","content":usertemplete.format(demo_code = demo_code)}
            #m3 = {"role":"assistant","content":assistenettemplete.format(demo_json = demo_json)}
            #rootmessages = [m1,m2,m3]
            m1 = {'role':'system','content':systemprompt}
            rootmessages = [m1]
            messages = rootmessages
            messages.append({
                "role":"user",
                "content":user_prompt
            })
            result = LLM(messages)
            #print("test", result)
            test_cases = extract_python_code(result)[0]
            #exit()
            #test_cases = parse_json_block(result)
            #test_cases = "\n".join(test_cases["assert lines"])
            break
        except:
            import time
            time.sleep(1)
            continue
    #print("\n".join(test_cases["assert lines"]))
    #exit()    
    with open('/Users/jinghuang/Desktop/multiagent/logs/test_cases.txt', 'a') as f:
        f.write(test_cases)
        f.write('\n======\n')
    return test_cases

def parse_json_block(string):
    # define a regular expression pattern that matches the code block grammar
    pattern = r"{(.*)}"
    # use re.search to find the first match of the pattern in the string
    match = re.search(pattern, string, flags=re.DOTALL)
    # if there is a match, extract the code from the match object
    if match:
        code = match.group(0)
        # return a dictionary with the key "code" and the value as the code
        return json.loads(code)
    # if there is no match, return None
    else:
        return None
import re
def extract_python_code(text):
    pattern = r'```python\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches
#'''
create_unit_tests=Tool(
        name="Tester",
        func=create_unit_tests_35,
        description=(
            "Tester(code_question:str) -> Dict:\n"
            " - Useful for when you need to generate unit tests\n"
            " - Returns unit test cases.\n"
            " - `prompt`: a string representing the coding signature and docstring"
        ),
        stringify_rule=lambda args: f"Tester({args[0]})",
    )
#'''
if __name__=='__main__':
    test_cases = create_unit_tests_35('''from typing import List\n\n\ndef has_close_elements(numbers: List[float], threshold: float) -> bool:\n    \"\"\" Check if in given list of numbers, are any two numbers closer to each other than\n    given threshold.\n    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)\n    False\n    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)\n    True\n    \"\"\"\n
                            ''')
    print(test_cases)