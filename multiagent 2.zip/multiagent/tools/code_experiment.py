from .base import Tool
import contextlib
import io
import traceback
from typing import Optional
import multiprocessing
from openai import OpenAI
import sys
sys.path.append("/Users/jinghuang/Desktop/multiagent/LLM")
from openai_model import OpenAIModel
from http_openai_model import HttpOpenAIModel
#LLM = OpenAIModel()
LLM = HttpOpenAIModel()
class ReadWriteStringIO(io.StringIO):
    """StringIO that can be read from and written to"""

    def readable(self, *args, **kwargs):
        """Returns True if the IO object can be read."""
        return True    
class redirect_stdin(contextlib._RedirectStream):  # type: ignore
    _stream = "stdin"

def run_code(code: str, queue: multiprocessing.Queue):
    # this function runs the code in a subprocess and sends the output and error to the queue
    stream = ReadWriteStringIO()
    error_and_traceback = ""
    standard_out = ""
    try:
        with contextlib.redirect_stdout(stream):
            with contextlib.redirect_stderr(stream):
                with redirect_stdin(stream):
                    exec(code,{})
    except Exception as e:
        error_and_traceback = "".join(traceback.format_exception(None, e, e.__traceback__))
    standard_out = stream.getvalue()
    queue.put((error_and_traceback, standard_out)) # put the output and error in the queue

def get_error_old(code: str):
    queue = multiprocessing.Queue() # create a queue
    error_and_traceback = ""
    standard_out = ""
    print("executing")
    timeout_sec = 60 # set the timeout in seconds
    process = multiprocessing.Process(target=run_code, args=(code,queue)) # create a process to run the code and pass the queue
    process.start() # start the process
    process.join(timeout_sec) # wait for the process to finish or timeout
    if process.is_alive(): # check if the process is still running
        print("Aborting due to timeout") # print a message
        process.terminate() # terminate the process
        return "", "" # return empty strings
    else: # if the process finished
        error_and_traceback, standard_out = queue.get() # get the output and error from the queue
        return error_and_traceback, standard_out

def get_error(code: str):
    stream = ReadWriteStringIO()
    error_and_traceback = ""
    standard_out = ""
    try:
        with contextlib.redirect_stdout(stream):
            with contextlib.redirect_stderr(stream):
                with redirect_stdin(stream):
                    exec(code,{})
    except Exception as e:
        error_and_traceback = "".join(traceback.format_exception(None, e, e.__traceback__))
    standard_out = stream.getvalue()
    return error_and_traceback, standard_out
import re
def extract_text(text):
    pattern = r'```\s*(.*?)\s*```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches

def extract_python_code(file_content):
    code_sections = []
    start_token = "```python"
    end_token = "```"

    # Splitting the file content into parts based on start_token
    parts = file_content.split(start_token)

    # Extracting the code sections from each part
    for part in parts[1:]:  # Starting from 1 to skip the first part before the first code section
        code_section = part.split(end_token)[0].strip()  # Extracting the code section before the end token
        code_sections.append(code_section)
    return code_sections

def parser(res):
    sections = extract_python_code(res)
    code,test = sections
    x = 0
    if code != '...':
        x = 1
    elif test != '...':
        x = 2    
    return x,code,test
#print(parser(analysis))

async def experiment_35(codes):
    print("Experimenter working ...")
    codes = codes.split('+++')
    CURRENT_CODE_QUESTION, code, testcases = codes[0], codes[1], codes[2]
    #print(code)
    #print(testcases)
    #exit()
    #prompt = '''"from typing import List\n\n\ndef has_close_elements(numbers: List[float], threshold: float) -> bool:\n    \"\"\" Check if in given list of numbers, are any two numbers closer to each other than\n    given threshold.\n    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)\n    False\n    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)\n    True\n    \"\"\"\n"''' 
    prompt = CURRENT_CODE_QUESTION
    '''
        ##modified code draft
    ```python
    YOUR_MODIFIED_CODE_DRAFT
    ```
    YOU MUST KEPP CLEAN INDENATION AND INCLUDE NECESSARY IMPORT. for example: `import math`, `from typing import List`, and etc.
    attention ! there should not be any ASSERT out side of comment , because when running , the testcases will be paste automatically to the bottom of the code . so your code always end with `\n    return ...`

    '''
    system_prompt = '''
    You are a helpful assistant who can give users the analysis on how to modify their codes. 
    Users will give you a task description, a draft code, some test cases, and the standard output and error messages for reference. 
    You need to consider all these information and give a reply. In your reply, there should be a short analysis that includes:

    A summary of the task and its main objective
    The steps to solve the task using the draft code or a modified version of it
    A comparison of the draft code output and the standard output, and an explanation of any differences or errors
    Any suggestions or tips to improve the code quality, efficiency, or readability
    You must follow this format:

    #reply 
    ##analysis:
    Analysis:
    YOUR_ANALYSIS_HERE
    '''

    uesr_prompt = '''
    here is the info you need to analyze
    the task is complete this:
    ```python
    {prompt}
    ```

    here is the draft file:
    ```python
    {exctuable}
    ```
    based on the task , it should be able to pass the cases:
    ```python
    {cases}
    ```
    
    i paste the test cases to the bottom of the draft file and run you can refer the standerd out 
    ```
    {out}
    ```
    and the error message:
    ```
    {error}
    ```
    '''
    userprompt1 = '''
    there is the original file to complete:
    ```python
    {task}
    ```
    here is the completetion:
    ```python
    {code}
    ```
    based on the task , it should be able to pass the cases:
    ```python
    {testcases}
    ```
    you can refer the standerd out 
    ```
    {out}
    ```
    and the error message:
    ```
    {error}
    ```
    please analysis which part need to be modify , the test case , or the code , for the part don't need modify , return '...' , reply with this format:
    # reply
    ## analysis
    YOUR_ANALYSIS
    ## modified code completion
    ```python
    ...
    ```
    ## modified test case
    ```python
    ...
    ```
    '''
    error, out = get_error(code+'\n'+testcases)
    #error_and_traceback = get_error(codes)
    if not error:
        return ''+'+sep+'+code+'+sep+'+''+'+sep+'+testcases+'+sep+'+''+'+sep+'+prompt
    '''
    query = uesr_prompt.format(
            prompt = prompt,
            exctuable = code,
            cases = testcases,
            error = error,
            out=out
        )
    '''
    query = userprompt1.format(
            task=prompt,
            code=code,
            testcases=testcases,
            out = out,
            error=error
        )
    messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
            #{"role": "assistant", "content": sample_solution},
            #{"role": "user", "content": f"Help me to write python solution for this coding quesion: {code_questions}. Make sure the python solution is in ```python code snippet."},
        ]
    analysis = LLM(messages)
    #prompt_final = systemprompt + '\n' + quary
    #analysis = LLM(prompt_final)
    #try:
    #    answer = extract_text(answer)[0]
    #except:
    #    answer = '```\n' + answer + '```'
    #    answer = extract_text(answer)[0]
    with open('/Users/jinghuang/Desktop/multiagent/logs/experiment.txt', 'a') as f:
        f.write(analysis)
        f.write('\n======\n')
    #error, out = get_error(answer+'\n'+testcases)
    #exit()
    
    return error+'+sep+'+code+'+sep+'+out+'+sep+'+testcases+'+sep+'+analysis+'+sep+'+prompt

async def experiment(codes):
    print("Experimenter working ...")
    codes = codes.split('+++')
    code, testcases = codes[0], codes[1]
    #print(code)
    #print(testcases)
    #exit()
    #prompt = '''"from typing import List\n\n\ndef has_close_elements(numbers: List[float], threshold: float) -> bool:\n    \"\"\" Check if in given list of numbers, are any two numbers closer to each other than\n    given threshold.\n    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)\n    False\n    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)\n    True\n    \"\"\"\n"''' 
    prompt = CURRENT_CODE_QUESTION
    '''
        ##modified code draft
    ```python
    YOUR_MODIFIED_CODE_DRAFT
    ```
    YOU MUST KEPP CLEAN INDENATION AND INCLUDE NECESSARY IMPORT. for example: `import math`, `from typing import List`, and etc.
    attention ! there should not be any ASSERT out side of comment , because when running , the testcases will be paste automatically to the bottom of the code . so your code always end with `\n    return ...`

    '''
    systemprompt = '''
    You are a helpful assistant who can give users the analysis on how to modify their codes. 
    Users will give you a task description, a draft code, some test cases, and the standard output and error messages for reference. 
    You need to consider all these information and give a reply. In your reply, there should be a short analysis that includes:

    A summary of the task and its main objective
    The steps to solve the task using the draft code or a modified version of it
    A comparison of the draft code output and the standard output, and an explanation of any differences or errors
    Any suggestions or tips to improve the code quality, efficiency, or readability
    You must follow this format:

    #reply 
    ##analysis:
    Analysis:
    YOUR_ANALYSIS_HERE
    '''

    uesrprompt = '''
    here is the info you need to analyze
    the task is complete this:
    ```python
    {prompt}
    ```

    here is the draft file:
    ```python
    {exctuable}
    ```
    based on the task , it should be able to pass the cases:
    ```python
    {cases}
    ```
    
    i paste the test cases to the bottom of the draft file and run you can refer the standerd out 
    ```
    {out}
    ```
    and the error message:
    ```
    {error}
    ```
    '''

    error, out = get_error(code+'\n'+testcases)
    #error_and_traceback = get_error(codes)
    if not error:
        return ''+'+sep+'+code+'+sep+'+''+'+sep+'+testcases+'+sep+'+''
    quary = uesrprompt.format(
            prompt = prompt,
            exctuable = code,
            cases = testcases,
            error = error,
            out=out
        )
    prompt_final = systemprompt + '\n' + quary
    analysis = LLM(prompt_final)
    #try:
    #    answer = extract_text(answer)[0]
    #except:
    #    answer = '```\n' + answer + '```'
    #    answer = extract_text(answer)[0]
    with open('/data0/panguchain/pgpts/agents/all_logs/experiment.txt', 'a') as f:
        f.write(analysis)
        f.write("=============================================")
    #error, out = get_error(answer+'\n'+testcases)
    #exit()
    return error+'+sep+'+code+'+sep+'+out+'+sep+'+testcases+'+sep+'+analysis



experiment=Tool(
        name="Experimenter",
        func=experiment_35,
        description=(
            "Experimenter(codes:str) -> str:\n"
            " - Useful for when you need to experiment codes\n"
            " - Returns python solution.\n"
            " - `code_quesion`: a string representing codes realted content"
        ),
        stringify_rule=lambda args: f"Experimenter({args[0]})",
    )









# Usage:
code = ''' 
import numpy as np
def f():
    print(np.pi)
    return np.pi
print(f())
'''
if __name__=='__main__':
    #error_and_traceback, standard_out = get_error(code)
    #print("Error and traceback:\n", error_and_traceback)
    #print("Standard out:\n", standard_out)
    answer = experiment('''from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    # Check if the list has at least two elements
    if len(numbers) < 2:
        return False
    # Loop through each pair of numbers in the list
    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            # Check if the absolute difference between the pair is less than the threshold
            if abs(numbers[i] - numbers[j]) < threshold:
                return True
    # Return False if no pair has an absolute difference less than the threshold
    return False
+++
assert has_close_elements([1.0, 2.0, 3.0], 0.5) == False, 'test case 1'
assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3) == True, 'test case 2'
assert has_close_elements([1.0, 2.0, 3.0, 4.0, 5.0], 0.2) == False, 'test case 3'
assert has_close_elements([1.0, 2.0, 3.0, 4.0, 5.0], 0.6) == False, 'test case 4'
                        ''')
    print(answer)