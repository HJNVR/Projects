import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import sys
sys.path.append("C:\\Users\\h84277374\\Desktop\\agents\\multiagent\\LLM")
from UniAIGC import UniAIGC
LLM = UniAIGC()
from .tool_agent import ToolAgent

from tools.discuss_codes import discuss

name = "DiscussionHoster"
role = "Discussion Hoster"
profile = f"{name}\n - Useful when you need to discuss codes\n"
systemprompt = f"""Your name is {name} and you role is {role}. 
{profile}
"""
tools = [discuss]
discusshoster = ToolAgent(name=name, 
                        role=role,
                        profile=profile, 
                        system_prompt=systemprompt,
                        llm=LLM, 
                        toollist=tools)